import pandas as pd
import re
import joblib

from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score


def clean_text(text):

    text = re.sub(r"http\S+", "", str(text))
    text = re.sub(r"@\w+", "", text)
    text = re.sub(r"#", "", text)
    text = re.sub(r"[^A-Za-z\s]", "", text)

    return text.lower()


# Load dataset
df = pd.read_csv(
    "datasets/training.1600000.processed.noemoticon.csv",
    encoding="latin-1",
    header=None
)

df = df[[0, 5]]

df.columns = [
    "sentiment",
    "tweet"
]

df["sentiment"] = df["sentiment"].replace(
    4,
    1
)

df["tweet"] = df["tweet"].apply(clean_text)

# Split
X_train, X_test, y_train, y_test = train_test_split(
    df["tweet"],
    df["sentiment"],
    test_size=0.2,
    random_state=42
)

# Vectorization
vectorizer = TfidfVectorizer(
    max_features=5000
)

X_train_vec = vectorizer.fit_transform(
    X_train
)

X_test_vec = vectorizer.transform(
    X_test
)

# Model
model = LogisticRegression(
    max_iter=1000
)

model.fit(
    X_train_vec,
    y_train
)

predictions = model.predict(
    X_test_vec
)

accuracy = accuracy_score(
    y_test,
    predictions
)

print(
    f"Accuracy: {accuracy:.4f}"
)

# Save
joblib.dump(
    model,
    "models/model.pkl"
)

joblib.dump(
    vectorizer,
    "models/vectorizer.pkl"
)

print("Model saved.")
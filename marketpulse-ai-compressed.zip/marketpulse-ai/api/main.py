import sys, os, json, asyncio, threading
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from fastapi import FastAPI, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import StreamingResponse, FileResponse
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from pydantic import BaseModel
import numpy as np
import pandas as pd

app = FastAPI(title="MarketPulse AI", version="2.0")

# ── Security middleware ────────────────────────────────────────────────────────
@app.middleware("http")
async def add_security_headers(request, call_next):
    response = await call_next(request)
    response.headers["X-Frame-Options"]        = "SAMEORIGIN"
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["Referrer-Policy"]        = "strict-origin-when-cross-origin"
    response.headers["Permissions-Policy"]     = "camera=(), microphone=(), geolocation=()"
    response.headers["X-XSS-Protection"]       = "1; mode=block"
    return response

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://localhost:4173", "http://localhost:3000"],
    allow_methods=["*"],
    allow_headers=["*"],
)


# ── JSON serializer ────────────────────────────────────────────────────────────
def _safe(obj):
    if isinstance(obj, np.integer):  return int(obj)
    if isinstance(obj, np.floating): return float(obj)
    if isinstance(obj, np.ndarray):  return obj.tolist()
    if isinstance(obj, pd.Timestamp): return str(obj)
    raise TypeError(f"Not serializable: {type(obj)}")


def serialize_results(results: dict) -> dict:
    out = {k: v for k, v in results.items() if k != "raw_posts"}

    trends = results.get("trends", {})
    if trends:
        idf = trends.get("interest_over_time")
        if idf is not None and isinstance(idf, pd.DataFrame) and not idf.empty:
            topic = results.get("topic", "")
            out["trends"] = {
                "topic":          trends.get("topic", ""),
                "error":          trends.get("error"),
                "top_queries":    trends.get("top_queries", []),
                "rising_queries": trends.get("rising_queries", []),
                "emerging_topics":trends.get("emerging_topics", []),
                "interest_over_time": {
                    "dates":  [str(d) for d in idf.index],
                    "values": idf[topic].tolist() if topic in idf.columns else [],
                },
            }
        else:
            out["trends"] = {
                k: v for k, v in trends.items()
                if k != "interest_over_time"
            }
            out["trends"]["interest_over_time"] = None

    return json.loads(json.dumps(out, default=_safe))


# ── Health check ───────────────────────────────────────────────────────────────
@app.get("/api/health")
def health():
    return {"status": "ok", "version": "2.0"}


# ── SSE streaming analysis ─────────────────────────────────────────────────────
@app.get("/api/analyze/stream")
async def analyze_stream(
    topic: str = Query(..., min_length=1),
    limit: int = Query(100, ge=10, le=1000),
):
    queue: asyncio.Queue = asyncio.Queue()
    loop = asyncio.get_event_loop()

    def on_step(label: str, detail: str = ""):
        asyncio.run_coroutine_threadsafe(
            queue.put({"type": "step", "label": label, "detail": detail}), loop
        )

    def run_sync():
        try:
            from agents.workflow import run_pipeline
            result = run_pipeline(topic, post_limit=limit, on_step=on_step)
            safe = serialize_results(result)
            asyncio.run_coroutine_threadsafe(
                queue.put({"type": "done", "results": safe}), loop
            )
        except Exception as e:
            asyncio.run_coroutine_threadsafe(
                queue.put({"type": "error", "message": str(e)}), loop
            )

    thread = threading.Thread(target=run_sync, daemon=True)
    thread.start()

    async def event_generator():
        yield "data: " + json.dumps({"type": "start", "topic": topic}) + "\n\n"
        while True:
            try:
                item = await asyncio.wait_for(queue.get(), timeout=180)
            except asyncio.TimeoutError:
                yield "data: " + json.dumps({"type": "error", "message": "Pipeline timeout"}) + "\n\n"
                break
            yield "data: " + json.dumps(item) + "\n\n"
            if item.get("type") in ("done", "error"):
                break

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no", "Connection": "keep-alive"},
    )


# ── Serve built React frontend ─────────────────────────────────────────────────
_dist = os.path.join(os.path.dirname(__file__), "..", "frontend", "dist")
if os.path.isdir(_dist):
    app.mount("/assets", StaticFiles(directory=os.path.join(_dist, "assets")), name="assets")

    @app.get("/{full_path:path}")
    def spa_fallback(full_path: str):
        index = os.path.join(_dist, "index.html")
        return FileResponse(index)

import { useStore } from '../store'
import { motion } from 'framer-motion'
import { PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer } from 'recharts'

const SEV = {
  High:   { cls:'border-red-600/40 bg-red-900/15',    badge:'bg-red-900/40 text-red-300',    icon:'🔴' },
  Medium: { cls:'border-orange-500/40 bg-orange-900/15', badge:'bg-orange-900/40 text-orange-300', icon:'🟡' },
  Low:    { cls:'border-green-600/40 bg-green-900/15', badge:'bg-green-900/40 text-green-300', icon:'🟢' },
}
const TYPE_ICONS = { Sentiment:'💬', Data:'🗃', Trend:'📊', Opportunity:'🚀', System:'⚙️', Status:'✅' }

export default function Alerts() {
  const results = useStore(s => s.results)
  if (!results) return <Empty />

  const alerts = results.alerts || []
  if (!alerts.length) return (
    <div className="flex flex-col items-center justify-center h-64">
      <div className="text-4xl mb-3">✅</div>
      <p className="text-[#10B981] font-semibold">No alerts — all systems normal</p>
    </div>
  )

  const high = alerts.filter(a=>a.severity==='High')
  const med  = alerts.filter(a=>a.severity==='Medium')
  const low  = alerts.filter(a=>a.severity==='Low')

  const typeCounts = {}
  alerts.forEach(a => { typeCounts[a.type||'General'] = (typeCounts[a.type||'General']||0)+1 })
  const pieData = Object.entries(typeCounts).map(([name,value])=>({name,value}))
  const PIE_COLORS = ['#FF4757','#FCD34D','#38BDF8','#A78BFA','#10FDAA']

  return (
    <div>
      <h1 className="text-2xl font-black gradient-text mb-1">🚨 Alerts & Signals</h1>
      <p className="text-[#94A3B8] text-sm mb-6">Automated anomaly detection · Sentiment signals · Data quality</p>

      <div className="grid grid-cols-4 gap-3 mb-6">
        {[['Total',alerts.length,'#38BDF8'],['🔴 Critical',high.length,'#FF4757'],['🟡 Warning',med.length,'#FCD34D'],['🟢 Info',low.length,'#10FDAA']].map(([l,n,c])=>(
          <div key={l} className="glass p-4 text-center">
            <div className="text-3xl font-black" style={{color:c}}>{n}</div>
            <div className="text-[10px] text-[#94A3B8] uppercase tracking-widest mt-1">{l}</div>
          </div>
        ))}
      </div>

      {pieData.length > 1 && (
        <div className="glass p-5 mb-6" style={{maxWidth:360}}>
          <div className="sec-hdr">Alerts by Type</div>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie data={pieData} cx="50%" cy="50%" innerRadius={50} outerRadius={80} paddingAngle={3} dataKey="value">
                {pieData.map((_,i)=><Cell key={i} fill={PIE_COLORS[i%PIE_COLORS.length]} stroke="#050B18" strokeWidth={2}/>)}
              </Pie>
              <Tooltip contentStyle={{background:'#0F1A2E',border:'1px solid #1E2D45',borderRadius:10,color:'#F1F5F9'}}/>
              <Legend formatter={v=><span style={{color:'#94A3B8',fontSize:12}}>{v}</span>}/>
            </PieChart>
          </ResponsiveContainer>
        </div>
      )}

      {[['🔴 Critical Alerts',high],['🟡 Warning Alerts',med],['🟢 Info & Signals',low]].map(([title,list])=>
        list.length > 0 && (
          <div key={title}>
            <div className="sec-hdr">{title}</div>
            <div className="space-y-2 mb-4">
              {list.map((a,i)=>(
                <motion.div key={i} initial={{opacity:0,x:-8}} animate={{opacity:1,x:0}} transition={{delay:i*.05}}
                  className={`flex gap-3 items-start p-4 rounded-xl border ${SEV[a.severity].cls}`}>
                  <span className={`text-[11px] font-bold px-2.5 py-1 rounded-full flex-shrink-0 mt-0.5 ${SEV[a.severity].badge}`}>
                    {SEV[a.severity].icon} {a.severity}
                  </span>
                  <div>
                    <p className="text-sm text-[#CBD5E1]">{a.message}</p>
                    <p className="text-[11px] text-[#718096] mt-1">{TYPE_ICONS[a.type]||'ℹ️'} {a.type}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        )
      )}
    </div>
  )
}

function Empty() {
  return <div className="flex items-center justify-center h-64 text-[#718096]">Run an analysis first ↑</div>
}

import { useState, useMemo } from 'react'
import { useStore } from '../store'

export default function Explorer() {
  const results = useStore(s => s.results)
  const [q, setQ] = useState('')
  const [src, setSrc] = useState('All')
  const [sent, setSent] = useState('All')
  const [sortCol, setSortCol] = useState('created')
  const [sortAsc, setSortAsc] = useState(false)

  if (!results) return <Empty />

  const sr = results.sentiment_results || []
  const sources = ['All', ...new Set(sr.map(r=>r.source).filter(Boolean))]

  const filtered = useMemo(() => {
    let out = sr
    if (q)           out = out.filter(r => (r.original_text||r.tweet||'').toLowerCase().includes(q.toLowerCase()))
    if (src !== 'All') out = out.filter(r => r.source === src)
    if (sent !== 'All') out = out.filter(r => r.sentiment === sent)
    return [...out].sort((a,b) => {
      const av = a[sortCol]||'', bv = b[sortCol]||''
      return sortAsc ? av > bv ? 1:-1 : av < bv ? 1:-1
    })
  }, [sr, q, src, sent, sortCol, sortAsc])

  const posN = filtered.filter(r=>r.sentiment==='Positive').length
  const negN = filtered.length - posN

  function toCSV() {
    const h = ['Source','Text','Sentiment','Created','URL']
    const rows = filtered.map(r => [r.source, `"${(r.original_text||r.tweet||'').replace(/"/g,'""')}"`, r.sentiment, r.created, r.url].join(','))
    const blob = new Blob([[h.join(','), ...rows].join('\n')], { type:'text/csv' })
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob)
    a.download = `posts_${results.topic.replace(/\s/g,'_')}.csv`; a.click()
  }

  function sortBy(col) {
    if (sortCol === col) setSortAsc(a => !a)
    else { setSortCol(col); setSortAsc(true) }
  }

  return (
    <div>
      <h1 className="text-2xl font-black gradient-text mb-1">🔍 Post Explorer</h1>
      <p className="text-[#94A3B8] text-sm mb-6">Browse, search, filter and export · Click any URL to open original</p>

      {/* Filters */}
      <div className="flex gap-3 flex-wrap mb-4">
        <input className="flex-1 min-w-48 bg-[#0A1020] border border-[#1E2D45] rounded-xl px-3 py-2 text-sm text-[#F1F5F9] placeholder-[#475569] focus:outline-none focus:border-indigo/50"
          value={q} onChange={e=>setQ(e.target.value)} placeholder="🔍 Search post text…" />
        <select className="bg-[#0A1020] border border-[#1E2D45] rounded-xl px-3 py-2 text-sm text-[#F1F5F9] focus:outline-none focus:border-indigo/50"
          value={src} onChange={e=>setSrc(e.target.value)}>
          {sources.map(s=><option key={s}>{s}</option>)}
        </select>
        <select className="bg-[#0A1020] border border-[#1E2D45] rounded-xl px-3 py-2 text-sm text-[#F1F5F9] focus:outline-none focus:border-indigo/50"
          value={sent} onChange={e=>setSent(e.target.value)}>
          {['All','Positive','Negative'].map(s=><option key={s}>{s}</option>)}
        </select>
        <button onClick={toCSV} className="px-4 py-2 rounded-xl bg-indigo/15 border border-indigo/30 text-[#A5B4FC] text-sm font-semibold hover:bg-indigo/25 transition-all">
          ⬇ CSV
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-5 gap-3 mb-4">
        {[['Showing',filtered.length,'#38BDF8'],['Total',sr.length,'#94A3B8'],['Positive',posN,'#10FDAA'],['Negative',negN,'#FF4757'],['Pos Rate',filtered.length ? `${Math.round(posN/filtered.length*100)}%` : '0%','#A78BFA']].map(([l,v,c])=>(
          <div key={l} className="glass p-3 text-center">
            <div className="text-xl font-black" style={{color:c}}>{v}</div>
            <div className="text-[10px] text-[#94A3B8] uppercase tracking-widest mt-0.5">{l}</div>
          </div>
        ))}
      </div>

      {/* Table */}
      <div className="glass overflow-hidden">
        <div className="overflow-x-auto max-h-[600px] overflow-y-auto">
          <table className="w-full text-sm">
            <thead className="sticky top-0 bg-[#0A1020]">
              <tr>
                {[['source','Source'],['original_text','Text'],['sentiment','Sentiment'],['created','Created'],['url','URL']].map(([col,label])=>(
                  <th key={col} onClick={()=>sortBy(col)}
                    className="text-left px-4 py-3 text-[10px] font-bold text-[#94A3B8] uppercase tracking-wider border-b border-[#1E2D45] cursor-pointer hover:text-[#CBD5E1] select-none whitespace-nowrap">
                    {label} {sortCol===col ? (sortAsc?'↑':'↓') : ''}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((r,i)=>(
                <tr key={i} className="border-b border-[#0F1A2E] hover:bg-[#0F1A2E]/60 transition-colors">
                  <td className="px-4 py-3 text-[#94A3B8] font-medium whitespace-nowrap">{r.source}</td>
                  <td className="px-4 py-3 text-[#CBD5E1] max-w-sm">
                    <div className="line-clamp-2 text-xs leading-relaxed">{r.original_text||r.tweet}</div>
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap">
                    <span className={`px-2 py-0.5 rounded-full text-xs font-bold ${r.sentiment==='Positive'?'bg-green-900/30 text-pos':'bg-red-900/30 text-neg'}`}>
                      {r.sentiment}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-[#718096] whitespace-nowrap text-xs">{r.created}</td>
                  <td className="px-4 py-3">
                    {r.url ? (
                      <a href={r.url} target="_blank" rel="noopener noreferrer"
                        className="text-indigo hover:text-[#A5B4FC] text-xs underline whitespace-nowrap">
                        Open ↗
                      </a>
                    ) : '—'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}

function Empty() {
  return <div className="flex items-center justify-center h-64 text-[#718096]">Run an analysis first ↑</div>
}

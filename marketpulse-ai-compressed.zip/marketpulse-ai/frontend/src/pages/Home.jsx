import { motion } from 'framer-motion'
import { useStore } from '../store'
import KpiCard from '../components/KpiCard'
import { CheckCircle, XCircle } from 'lucide-react'

const TOPICS = ['Artificial Intelligence', 'Electric Vehicles', 'Climate Change', 'ChatGPT', 'Tesla']

export default function Home() {
  const { results, setTopic, analyze, limit } = useStore()

  if (!results) return (
    <div className="flex flex-col items-center justify-center min-h-[80vh] text-center">
      <motion.div
        animate={{ y: [0, -12, 0] }} transition={{ repeat: Infinity, duration: 3, ease: 'easeInOut' }}
        className="text-7xl mb-6"
      >📡</motion.div>
      <h1 className="text-3xl font-black gradient-text mb-3">MarketPulse AI</h1>
      <p className="text-[#718096] text-base max-w-md leading-relaxed mb-8">
        Real-time sentiment intelligence · Reddit & Google News · ML analysis ·
        Google Trends · Gemini AI · No API keys needed
      </p>
      <div className="flex flex-wrap justify-center gap-2">
        {TOPICS.map(t => (
          <motion.button key={t} whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.97 }}
            onClick={() => { setTopic(t); analyze(t, limit) }}
            className="px-4 py-2 rounded-full glass border border-indigo/25 text-[#A5B4FC] text-sm hover:border-indigo/50 transition-all">
            💡 {t}
          </motion.button>
        ))}
      </div>
    </div>
  )

  const { topic, timestamp, total_posts, positive_pct, negative_pct, sources_used = [],
          keywords = [], recommendations = [], alerts = [], summary, sentiment_results = [],
          trends = {} } = results

  const posN = sentiment_results.filter(r => r.sentiment === 'Positive').length
  const negN = sentiment_results.length - posN
  const highN = alerts.filter(a => a.severity === 'High').length
  const trendsOk = trends?.interest_over_time?.values?.length > 0
  const geminiOk = results.insights && !results.insights.startsWith('⚠️') && !results.insights.includes('not set')

  const STATUS = [
    ['🌐', 'Reddit',       sources_used.includes('Reddit')],
    ['📰', 'Google News',  sources_used.includes('Google News')],
    ['📊', 'Google Trends',trendsOk],
    ['🤖', 'Gemini AI',    geminiOk],
    ['🧠', 'ML Sentiment', total_posts > 0],
  ]

  return (
    <div>
      {/* Hero */}
      <motion.div initial={{ opacity:0, y:-10 }} animate={{ opacity:1, y:0 }}
        className="glass p-6 mb-6 relative overflow-hidden">
        <div className="absolute inset-0 pointer-events-none"
          style={{ background: 'radial-gradient(ellipse at 20% 50%,rgba(99,102,241,.07) 0%,transparent 55%), radial-gradient(ellipse at 80% 30%,rgba(6,182,212,.05) 0%,transparent 50%)' }} />
        <h1 className="text-2xl font-black gradient-text">📡 MarketPulse AI</h1>
        <p className="text-[#94A3B8] text-sm mt-1">Real-Time Sentiment & Trend Intelligence · {timestamp}</p>
        <div className="flex gap-6 mt-4 flex-wrap">
          {[
            [total_posts, 'Posts Analysed', '#38BDF8'],
            [`${positive_pct}%`, 'Positive', '#10FDAA'],
            [`${negative_pct}%`, 'Negative', '#FF4757'],
            [sources_used.length, 'Sources', '#A78BFA'],
          ].map(([v, l, c]) => (
            <div key={l}>
              <div className="text-2xl font-black" style={{ color: c }}>{v}</div>
              <div className="text-[10px] text-[#718096] uppercase tracking-widest">{l}</div>
            </div>
          ))}
        </div>
      </motion.div>

      {/* KPI grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 mb-6">
        <KpiCard icon="📄" label="Total Posts"  value={total_posts}    color="blue"   delta="Reddit + News"           delay={.04}/>
        <KpiCard icon="🟢" label="Positive"     value={`${positive_pct}%`} color="green" delta={`${posN} posts`}    delay={.08}/>
        <KpiCard icon="🔴" label="Negative"     value={`${negative_pct}%`} color="red"   delta={`${negN} posts`}    delay={.12}/>
        <KpiCard icon="🔑" label="Top Keyword"  value={keywords[0]?.[0] || '—'} color="purple" delta={`${keywords.length} extracted`} delay={.16}/>
        <KpiCard icon="🎯" label="Actions"      value={recommendations.length} color="cyan" delta="AI recommendations" delay={.20}/>
        <KpiCard icon="🚨" label="Alerts"       value={alerts.length}  color={highN ? 'red' : 'amber'} delta={highN ? `${highN} critical` : 'All clear'} delay={.24}/>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        {/* Status */}
        <div className="glass p-5">
          <div className="sec-hdr">System Status</div>
          {STATUS.map(([ico, name, ok]) => (
            <div key={name} className="flex items-center gap-3 py-2 border-b border-[#0F1A2E] last:border-0">
              <div className={`w-2 h-2 rounded-full flex-shrink-0 ${ok ? 'bg-[#10B981] shadow-[0_0_6px_#10B981]' : 'bg-[#374151]'}`}
                style={ok ? { animation: 'pulse-dot 2s infinite' } : {}} />
              <span className="text-sm flex-1">{ico} {name}</span>
              <span className={`text-xs ${ok ? 'text-[#10B981]' : 'text-[#718096]'}`}>
                {ok ? 'Active' : name === 'Gemini AI' ? 'No key' : 'Unavailable'}
              </span>
            </div>
          ))}
        </div>

        {/* Summary */}
        <div className="lg:col-span-2 glass p-5">
          <div className="sec-hdr">Pipeline Summary</div>
          <pre className="text-sm text-[#CBD5E1] leading-relaxed whitespace-pre-wrap font-sans">{summary}</pre>
        </div>
      </div>

      {/* Alerts preview */}
      <div className="sec-hdr">Alerts</div>
      <div className="space-y-2 mb-6">
        {alerts.slice(0,4).map((a, i) => {
          const cls = { High: 'border-red-600/40 bg-red-900/20', Medium: 'border-orange-500/40 bg-orange-900/20', Low: 'border-green-600/40 bg-green-900/20' }
          const icons = { High: '🔴', Medium: '🟡', Low: '🟢' }
          return (
            <motion.div key={i} initial={{ opacity:0, x:-8 }} animate={{ opacity:1, x:0 }} transition={{ delay: i*.05 }}
              className={`flex gap-3 items-start p-3 rounded-xl border ${cls[a.severity]}`}>
              <span className="text-sm font-bold mt-0.5 flex-shrink-0 px-2 py-0.5 rounded-full text-[11px]
                ${a.severity==='High' ? 'bg-red-900/40 text-red-300' : a.severity==='Medium' ? 'bg-orange-900/40 text-orange-300' : 'bg-green-900/40 text-green-300'}">
                {icons[a.severity]} {a.severity}
              </span>
              <span className="text-sm text-[#CBD5E1]">{a.message}</span>
            </motion.div>
          )
        })}
      </div>
    </div>
  )
}

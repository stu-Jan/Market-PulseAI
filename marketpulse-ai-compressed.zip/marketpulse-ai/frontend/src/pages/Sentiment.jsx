import { useStore } from '../store'
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'
import { motion } from 'framer-motion'

const CHART = { pos: '#10FDAA', neg: '#FF4757', bg: 'transparent', grid: 'rgba(30,45,69,0.5)', text: '#94A3B8' }

export default function Sentiment() {
  const results = useStore(s => s.results)
  if (!results) return <Empty />

  const sr = results.sentiment_results || []
  const pos = sr.filter(r => r.sentiment === 'Positive').length
  const neg = sr.length - pos
  const tot = sr.length || 1
  const pie = [{ name: 'Positive', value: pos }, { name: 'Negative', value: neg }]

  // By source
  const bySrc = {}
  sr.forEach(r => {
    const src = r.source || 'Unknown'
    if (!bySrc[src]) bySrc[src] = { source: src, Positive: 0, Negative: 0 }
    bySrc[src][r.sentiment]++
  })
  const srcData = Object.values(bySrc)

  return (
    <div>
      <h1 className="text-2xl font-black gradient-text mb-1">📊 Sentiment Analysis</h1>
      <p className="text-[#94A3B8] text-sm mb-6">ML-powered classification · {sr.length} posts analysed</p>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        {/* Donut */}
        <div className="glass p-5">
          <div className="sec-hdr">Sentiment Distribution</div>
          <ResponsiveContainer width="100%" height={280}>
            <PieChart>
              <Pie data={pie} cx="50%" cy="50%" innerRadius={70} outerRadius={110} paddingAngle={3} dataKey="value">
                {pie.map((_, i) => <Cell key={i} fill={i === 0 ? CHART.pos : CHART.neg} stroke="#050B18" strokeWidth={3} />)}
              </Pie>
              <Tooltip contentStyle={{ background:'#0F1A2E', border:'1px solid #1E2D45', borderRadius:10, color:'#F1F5F9' }} />
              <Legend formatter={v => <span style={{color:'#94A3B8'}}>{v}</span>} />
            </PieChart>
          </ResponsiveContainer>
          <div className="flex justify-center gap-8 mt-2">
            <div className="text-center">
              <div className="text-2xl font-black text-pos">{pos}</div>
              <div className="text-[10px] text-[#94A3B8] uppercase tracking-widest">Positive</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-black text-neg">{neg}</div>
              <div className="text-[10px] text-[#94A3B8] uppercase tracking-widest">Negative</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-black text-cyan">{Math.round(pos/tot*100)}%</div>
              <div className="text-[10px] text-[#94A3B8] uppercase tracking-widest">Pos Rate</div>
            </div>
          </div>
        </div>

        {/* Bar by source */}
        <div className="glass p-5">
          <div className="sec-hdr">Sentiment by Source</div>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={srcData} margin={{ top: 10, right: 20, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke={CHART.grid} />
              <XAxis dataKey="source" tick={{ fill: CHART.text, fontSize: 12 }} />
              <YAxis tick={{ fill: CHART.text, fontSize: 12 }} />
              <Tooltip contentStyle={{ background:'#0F1A2E', border:'1px solid #1E2D45', borderRadius:10, color:'#F1F5F9' }} />
              <Legend formatter={v => <span style={{color:'#94A3B8'}}>{v}</span>} />
              <Bar dataKey="Positive" fill={CHART.pos} radius={[4,4,0,0]} />
              <Bar dataKey="Negative" fill={CHART.neg} radius={[4,4,0,0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Table */}
      <div className="sec-hdr">All Posts</div>
      <div className="glass overflow-hidden">
        <div className="overflow-x-auto max-h-[500px] overflow-y-auto">
          <table className="w-full text-sm">
            <thead className="sticky top-0 bg-[#0A1020]">
              <tr>
                {['Source','Text','Sentiment','Created'].map(h => (
                  <th key={h} className="text-left px-4 py-3 text-[10px] font-bold text-[#94A3B8] uppercase tracking-wider border-b border-[#1E2D45]">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {sr.map((r, i) => (
                <tr key={i} className="border-b border-[#0F1A2E] hover:bg-[#0F1A2E]/50 transition-colors">
                  <td className="px-4 py-3 text-[#94A3B8] font-medium whitespace-nowrap">{r.source}</td>
                  <td className="px-4 py-3 text-[#CBD5E1] max-w-md">
                    <div className="line-clamp-2">{r.original_text || r.tweet}</div>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`px-2.5 py-1 rounded-full text-xs font-bold ${r.sentiment==='Positive' ? 'bg-green-900/30 text-pos' : 'bg-red-900/30 text-neg'}`}>
                      {r.sentiment}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-[#718096] whitespace-nowrap text-xs">{r.created}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}

function Empty() {
  return <div className="flex items-center justify-center h-64 text-[#718096]">Run an analysis first ↑</div>
}

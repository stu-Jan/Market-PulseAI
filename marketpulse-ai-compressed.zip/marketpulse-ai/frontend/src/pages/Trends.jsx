import { useStore } from '../store'
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'

const TT = { contentStyle: { background:'#0F1A2E', border:'1px solid #1E2D45', borderRadius:10, color:'#F1F5F9' } }
const GRID = 'rgba(30,45,69,0.5)'
const T = { fill: '#94A3B8', fontSize: 11 }

export default function Trends() {
  const results = useStore(s => s.results)
  if (!results) return <Empty />

  const kw = results.keywords || []
  const tr = results.trends || {}
  const iot = tr.interest_over_time
  const lineData = iot?.dates?.map((d, i) => ({ date: d.slice(5,16), value: iot.values[i] })) || []

  const kwData = kw.slice(0,15).map(([word, count]) => ({ word, count })).reverse()

  return (
    <div>
      <h1 className="text-2xl font-black gradient-text mb-1">📈 Trends & Keywords</h1>
      <p className="text-[#94A3B8] text-sm mb-6">Top keywords from posts · Google Trends interest · Related queries</p>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        {/* Keyword cloud */}
        <div className="glass p-5">
          <div className="sec-hdr">Keyword Cloud</div>
          <div className="flex flex-wrap gap-2 mt-2">
            {kw.slice(0,20).map(([word, count], i) => {
              const max = kw[0]?.[1] || 1
              const sz = 0.72 + 0.35 * (count / max)
              return (
                <span key={word} className="px-3 py-1 rounded-full border border-indigo/20 bg-indigo/8 text-[#A5B4FC] transition-all hover:border-indigo/40"
                  style={{ fontSize: `${sz}rem` }}>
                  {word} <span className="text-indigo font-bold text-xs">{count}</span>
                </span>
              )
            })}
          </div>
        </div>

        {/* Keyword bar */}
        <div className="glass p-5">
          <div className="sec-hdr">Keyword Frequency</div>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={kwData} layout="vertical" margin={{ top:0, right:40, left:60, bottom:0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke={GRID} />
              <XAxis type="number" tick={T} />
              <YAxis dataKey="word" type="category" tick={{ fill:'#94A3B8', fontSize:11 }} width={60} />
              <Tooltip {...TT} />
              <Bar dataKey="count" fill="url(#kwGrad)" radius={[0,4,4,0]} label={{ position:'right', fill:'#94A3B8', fontSize:10 }}>
                <defs>
                  <linearGradient id="kwGrad" x1="0" y1="0" x2="1" y2="0">
                    <stop offset="0%" stopColor="#6366F1" />
                    <stop offset="100%" stopColor="#06B6D4" />
                  </linearGradient>
                </defs>
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Google Trends line chart */}
      <div className="glass p-5 mb-6">
        <div className="sec-hdr">Google Trends — Interest Over Time (Last 7 Days)</div>
        {lineData.length > 0 ? (
          <ResponsiveContainer width="100%" height={240}>
            <LineChart data={lineData} margin={{ top:10, right:20, left:0, bottom:0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke={GRID} />
              <XAxis dataKey="date" tick={T} />
              <YAxis domain={[0,100]} tick={T} />
              <Tooltip {...TT} />
              <Line type="monotone" dataKey="value" stroke="#6366F1" strokeWidth={2.5}
                dot={{ fill:'#6366F1', r:3 }} activeDot={{ r:5 }}
                name={results.topic} />
            </LineChart>
          </ResponsiveContainer>
        ) : (
          <div className="text-center text-[#718096] py-10 text-sm">
            {tr.error ? `⚠️ ${tr.error}` : 'Google Trends data not available for this topic.'}
          </div>
        )}
      </div>

      {/* Related + Rising queries */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        <QueryTable title="Top Related Queries" data={tr.top_queries || []} />
        <QueryTable title="Rising Queries" data={tr.rising_queries || []} />
      </div>

      {/* Emerging topics */}
      {(tr.emerging_topics || []).length > 0 && (
        <>
          <div className="sec-hdr">Emerging Topics</div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
            {tr.emerging_topics.map((t, i) => (
              <div key={i} className="glass p-4 text-center">
                <div className="text-2xl mb-2">{['🚀','⚡','🌊','🔥','💎','🎯'][i % 6]}</div>
                <div className="text-sm font-semibold text-[#CBD5E1]">{t}</div>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  )
}

function QueryTable({ title, data }) {
  return (
    <div className="glass p-5">
      <div className="sec-hdr">{title}</div>
      {data.length > 0 ? (
        <table className="w-full text-sm">
          <thead><tr>
            {Object.keys(data[0]).map(k => (
              <th key={k} className="text-left pb-2 text-[10px] font-bold text-[#94A3B8] uppercase tracking-wider">{k}</th>
            ))}
          </tr></thead>
          <tbody>
            {data.map((row, i) => (
              <tr key={i} className="border-t border-[#0F1A2E]">
                {Object.values(row).map((v, j) => (
                  <td key={j} className="py-2 text-[#CBD5E1]">{v}</td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <div className="text-[#718096] text-sm py-6 text-center">No data available.</div>
      )}
    </div>
  )
}

function Empty() {
  return <div className="flex items-center justify-center h-64 text-[#718096]">Run an analysis first ↑</div>
}

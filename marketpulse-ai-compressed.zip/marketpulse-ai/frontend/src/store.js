import { create } from 'zustand'

export const useStore = create((set, get) => ({
  results:    null,
  steps:      [],
  running:    false,
  topic:      'Artificial Intelligence',
  limit:      100,

  setTopic:  (t) => set({ topic: t }),
  setLimit:  (l) => set({ limit: l }),

  analyze: (topic, limit) => {
    set({ running: true, steps: [], results: null })

    const url = `/api/analyze/stream?topic=${encodeURIComponent(topic)}&limit=${limit}`
    const es = new EventSource(url)

    es.onmessage = (e) => {
      const data = JSON.parse(e.data)

      if (data.type === 'step') {
        set(s => ({ steps: [...s.steps, { label: data.label, detail: data.detail }] }))
      }
      if (data.type === 'done') {
        set({ results: data.results, running: false, steps: [] })
        es.close()
      }
      if (data.type === 'error') {
        set(s => ({
          running: false,
          steps: [...s.steps, { label: `❌ ${data.message}`, detail: '' }],
        }))
        es.close()
      }
    }

    es.onerror = () => {
      set({ running: false })
      es.close()
    }
  },
}))

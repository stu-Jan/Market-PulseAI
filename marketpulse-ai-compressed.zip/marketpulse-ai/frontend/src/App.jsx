import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Layout from './components/Layout'
import Home from './pages/Home'
import Sentiment from './pages/Sentiment'
import Trends from './pages/Trends'
import Insights from './pages/Insights'
import Recommendations from './pages/Recommendations'
import Alerts from './pages/Alerts'
import Explorer from './pages/Explorer'

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route element={<Layout />}>
          <Route path="/"                index element={<Home />} />
          <Route path="/sentiment"       element={<Sentiment />} />
          <Route path="/trends"          element={<Trends />} />
          <Route path="/insights"        element={<Insights />} />
          <Route path="/recommendations" element={<Recommendations />} />
          <Route path="/alerts"          element={<Alerts />} />
          <Route path="/explorer"        element={<Explorer />} />
        </Route>
      </Routes>
    </BrowserRouter>
  )
}

import { motion } from 'framer-motion'

const COLOR_MAP = {
  blue:   { val: 'text-cyan',            top: 'card-top-blue' },
  green:  { val: 'text-pos',             top: 'card-top-green' },
  red:    { val: 'text-neg',             top: 'card-top-red' },
  purple: { val: 'text-[#A78BFA]',       top: 'card-top-purple' },
  amber:  { val: 'text-amber',           top: 'card-top-amber' },
  cyan:   { val: 'text-[#67E8F9]',       top: 'card-top-cyan' },
}

export default function KpiCard({ icon, label, value, color = 'blue', delta, delay = 0 }) {
  const c = COLOR_MAP[color] || COLOR_MAP.blue
  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.35, ease: 'easeOut' }}
      whileHover={{ y: -4, transition: { duration: 0.2 } }}
      className={`glass ${c.top} p-4 text-center cursor-default`}
    >
      <div className="text-2xl mb-1">{icon}</div>
      <div className="text-[10px] font-bold text-[#94A3B8] uppercase tracking-widest mb-1.5">{label}</div>
      <div className={`text-3xl font-black leading-none ${c.val}`}>{value}</div>
      {delta && <div className="text-[11px] text-[#718096] mt-1.5">{delta}</div>}
    </motion.div>
  )
}

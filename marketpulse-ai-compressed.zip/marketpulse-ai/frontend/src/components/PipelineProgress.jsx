import { motion, AnimatePresence } from 'framer-motion'
import { useStore } from '../store'

export default function PipelineProgress() {
  const { steps, topic } = useStore()
  return (
    <div className="sticky top-0 z-40 bg-[#0A1020]/95 backdrop-blur border-b border-[#1E2D45] px-6 py-3">
      <div className="progress-bar w-full mb-2" />
      <div className="flex items-center gap-3">
        <span className="live-dot flex-shrink-0" />
        <span className="text-sm font-semibold text-[#A5B4FC]">
          Analysing <span className="text-white">"{topic}"</span>
        </span>
        <AnimatePresence mode="wait">
          {steps.length > 0 && (
            <motion.span
              key={steps[steps.length-1].label}
              initial={{ opacity: 0, x: 8 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0 }}
              className="text-xs text-[#94A3B8] truncate max-w-xs"
            >
              {steps[steps.length-1].label}
              {steps[steps.length-1].detail && (
                <span className="text-[#718096]"> — {steps[steps.length-1].detail}</span>
              )}
            </motion.span>
          )}
        </AnimatePresence>
      </div>
    </div>
  )
}

import { Outlet } from 'react-router-dom'
import Sidebar from './Sidebar'
import PipelineProgress from './PipelineProgress'
import { useStore } from '../store'

export default function Layout() {
  const running = useStore(s => s.running)

  return (
    <div className="flex min-h-screen bg-base text-[#F1F5F9]">
      <Sidebar />
      <main className="flex-1 ml-72 min-h-screen overflow-y-auto">
        {running && <PipelineProgress />}
        <div className="p-6 max-w-[1400px] mx-auto">
          <Outlet />
        </div>
      </main>
    </div>
  )
}

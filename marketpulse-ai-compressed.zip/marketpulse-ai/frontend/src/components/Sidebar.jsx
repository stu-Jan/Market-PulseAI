import { NavLink } from 'react-router-dom'
import { motion } from 'framer-motion'
import { useStore } from '../store'
import {
  LayoutDashboard, BarChart2, TrendingUp,
  Lightbulb, Target, Bell, Search, Play, Wifi
} from 'lucide-react'

const NAV = [
  { to: '/',                icon: LayoutDashboard, label: 'Dashboard' },
  { to: '/sentiment',       icon: BarChart2,        label: 'Sentiment' },
  { to: '/trends',          icon: TrendingUp,       label: 'Trends' },
  { to: '/insights',        icon: Lightbulb,        label: 'Insights' },
  { to: '/recommendations', icon: Target,           label: 'Recommendations' },
  { to: '/alerts',          icon: Bell,             label: 'Alerts' },
  { to: '/explorer',        icon: Search,           label: 'Post Explorer' },
]

const EXAMPLES = ['Artificial Intelligence', 'Electric Vehicles', 'ChatGPT', 'Tesla', 'Climate Change']

export default function Sidebar() {
  const { topic, setTopic, limit, setLimit, analyze, running, results } = useStore()

  const handleAnalyze = () => {
    if (!running && topic.trim()) analyze(topic.trim(), limit)
  }

  return (
    <aside className="fixed left-0 top-0 h-full w-72 bg-[#030712] border-r border-[#1E2D45] flex flex-col z-50 overflow-y-auto">
      {/* Brand */}
      <div className="px-5 py-5 border-b border-[#1E2D45]">
        <div className="text-xl font-black gradient-text tracking-tight">📡 MarketPulse AI</div>
        <div className="text-[11px] text-[#94A3B8] mt-0.5">Real-Time Sentiment Intelligence</div>
      </div>

      {/* Nav */}
      <nav className="px-3 py-3 border-b border-[#1E2D45]">
        {NAV.map(({ to, icon: Icon, label }) => (
          <NavLink
            key={to} to={to} end={to === '/'}
            className={({ isActive }) =>
              `flex items-center gap-3 px-3 py-2.5 rounded-xl mb-0.5 text-sm font-medium transition-all duration-150 ${
                isActive
                  ? 'bg-indigo/15 text-[#A5B4FC] border border-indigo/30'
                  : 'text-[#94A3B8] hover:bg-[#0F1A2E] hover:text-[#CBD5E1]'
              }`
            }
          >
            <Icon size={16} />
            {label}
          </NavLink>
        ))}
      </nav>

      {/* Search panel */}
      <div className="px-4 py-4 flex-1">
        <div className="text-[10px] font-bold text-[#718096] uppercase tracking-widest mb-2">Topic</div>
        <input
          className="w-full bg-[#0A1020] border border-[#1E2D45] rounded-xl px-3 py-2 text-sm text-[#F1F5F9] placeholder-[#475569] focus:outline-none focus:border-indigo/50 focus:ring-1 focus:ring-indigo/20 transition-all"
          value={topic}
          onChange={e => setTopic(e.target.value)}
          placeholder="e.g. ChatGPT, Tesla…"
          onKeyDown={e => e.key === 'Enter' && handleAnalyze()}
        />

        <div className="text-[10px] font-bold text-[#718096] uppercase tracking-widest mt-4 mb-2">
          Posts — {limit}
        </div>
        <input
          type="range" min={10} max={1000} step={10} value={limit}
          onChange={e => setLimit(Number(e.target.value))}
          className="w-full accent-indigo cursor-pointer"
        />
        <div className="flex justify-between text-[10px] text-[#475569] mt-0.5">
          <span>10</span><span>1000</span>
        </div>

        <motion.button
          whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.97 }}
          onClick={handleAnalyze}
          disabled={running}
          className="w-full mt-4 flex items-center justify-center gap-2 bg-gradient-to-r from-indigo to-[#8B5CF6] hover:from-[#4F46E5] hover:to-[#7C3AED] text-white font-semibold rounded-xl py-2.5 text-sm shadow-lg shadow-indigo/25 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
        >
          {running
            ? <><span className="live-dot" /><span>Analysing…</span></>
            : <><Play size={14} /><span>Analyze Now</span></>
          }
        </motion.button>

        {/* Quick examples */}
        <div className="text-[10px] font-bold text-[#718096] uppercase tracking-widest mt-4 mb-2">Quick Topics</div>
        <div className="flex flex-wrap gap-1.5">
          {EXAMPLES.map(ex => (
            <button
              key={ex}
              onClick={() => setTopic(ex)}
              className="text-[11px] px-2.5 py-1 rounded-full bg-[#0F1A2E] border border-[#1E2D45] text-[#94A3B8] hover:border-indigo/40 hover:text-[#A5B4FC] transition-all"
            >
              {ex}
            </button>
          ))}
        </div>

        {/* Last run info */}
        {results && (
          <div className="mt-4 p-3 rounded-xl bg-[#0A1020] border border-[#1E2D45]">
            <div className="text-[10px] font-bold text-[#718096] uppercase tracking-widest mb-2">Last Run</div>
            <div className="text-[13px] font-semibold text-[#F1F5F9] truncate">{results.topic}</div>
            <div className="text-[11px] text-[#718096] mt-0.5">🕐 {results.timestamp}</div>
            <div className="flex gap-3 mt-1.5">
              <span className="text-[11px] text-cyan">📄 {results.total_posts} posts</span>
              <span className={`text-[11px] ${results.positive_pct >= 50 ? 'text-pos' : 'text-neg'}`}>
                ● {results.positive_pct}% pos
              </span>
            </div>
          </div>
        )}
      </div>

      <div className="px-4 pb-4 text-[10px] text-[#334155] text-center">
        MarketPulse AI v2.0 · No API keys needed
      </div>
    </aside>
  )
}

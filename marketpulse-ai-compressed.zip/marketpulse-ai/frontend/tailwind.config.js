export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        base:    '#050B18',
        surface: '#0A1020',
        card:    '#0F1A2E',
        border:  '#1E2D45',
        indigo:  '#6366F1',
        cyan:    '#06B6D4',
        pos:     '#10FDAA',
        neg:     '#FF4757',
        amber:   '#FCD34D',
      },
      fontFamily: { sans: ['Inter', 'system-ui', 'sans-serif'] },
    },
  },
  plugins: [],
}

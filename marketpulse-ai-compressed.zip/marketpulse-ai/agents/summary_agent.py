def generate_summary(sentiment_results):

    positive = 0
    negative = 0

    for result in sentiment_results:

        if result["sentiment"] == "Positive":
            positive += 1
        else:
            negative += 1

    total = positive + negative

    if total == 0:
        return "No tweets found."

    positive_percent = round(
        (positive / total) * 100,
        2
    )

    negative_percent = round(
        (negative / total) * 100,
        2
    )

    report = f"""
Total Tweets Analysed: {total}

Positive Tweets: {positive}
Negative Tweets: {negative}

Positive Sentiment: {positive_percent}%
Negative Sentiment: {negative_percent}%
"""

    return report

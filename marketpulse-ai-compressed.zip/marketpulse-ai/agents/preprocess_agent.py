import re

def clean_tweet(text):

    text = re.sub(r"http\S+", "", text)
    text = re.sub(r"@\w+", "", text)
    text = re.sub(r"#", "", text)
    text = re.sub(r"[^A-Za-z\s]", "", text)

    return text.lower().strip()


def preprocess_tweets(tweets):

    return [clean_tweet(tweet) for tweet in tweets]


if __name__ == "__main__":

    sample = [
        "I LOVE AI!!! #AI",
        "Check this out https://google.com"
    ]

    print(preprocess_tweets(sample))

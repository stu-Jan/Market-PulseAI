import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from datetime import datetime
from typing import Callable, Optional

from sources.source_manager import collect_all_posts
from sources.trends_source import get_trends_data
from agents.preprocess_agent import preprocess_tweets
from agents.sentiment_agent import analyze_tweets
from agents.trend_agent import extract_keywords
from agents.summary_agent import generate_summary
from agents.insight_agent import generate_insights
from agents.recommendation_agent import generate_recommendations
from agents.alert_agent import generate_alerts


def run_pipeline(
    topic: str,
    post_limit: int = 50,
    on_step: Optional[Callable[[str, str], None]] = None,
) -> dict:
    """
    Run the full MarketPulse AI pipeline.
    on_step(label, detail) is called after each stage completes for live UI updates.
    """
    def step(label: str, detail: str = ""):
        if on_step:
            on_step(label, detail)

    result = {
        "topic": topic,
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "raw_posts": [],
        "sentiment_results": [],
        "keywords": [],
        "summary": "",
        "insights": "",
        "recommendations": [],
        "alerts": [],
        "trends": {},
        "sources_used": [],
        "total_posts": 0,
        "positive_pct": 0.0,
        "negative_pct": 0.0,
        "error": None,
    }

    try:
        step("🌐 Fetching posts", "Connecting to Reddit & Google News…")
        raw_posts = collect_all_posts(
            topic,
            reddit_limit=post_limit,
            news_limit=max(post_limit // 2, 15),
        )
        result["raw_posts"] = raw_posts
        result["sources_used"] = list(set(p["source"] for p in raw_posts))
        step("✅ Posts collected", f"{len(raw_posts)} posts from {', '.join(result['sources_used']) or 'no sources'}")

        step("🧹 Preprocessing", "Cleaning text — removing URLs, symbols, stopwords…")
        texts = [p["text"] for p in raw_posts]
        cleaned = preprocess_tweets(texts)
        step("✅ Preprocessing done", f"{len(cleaned)} texts cleaned")

        step("🧠 Sentiment analysis", "Running ML model on each post…")
        sentiment_results = analyze_tweets(cleaned)
        for i, res in enumerate(sentiment_results):
            if i < len(raw_posts):
                res["source"] = raw_posts[i]["source"]
                res["original_text"] = raw_posts[i]["text"]
                res["url"] = raw_posts[i].get("url", "")
                res["created"] = raw_posts[i].get("created", "")
        result["sentiment_results"] = sentiment_results

        total = len(sentiment_results)
        pos = sum(1 for r in sentiment_results if r["sentiment"] == "Positive")
        result["total_posts"] = total
        result["positive_pct"] = round((pos / total) * 100, 1) if total > 0 else 0.0
        result["negative_pct"] = round(((total - pos) / total) * 100, 1) if total > 0 else 0.0
        step("✅ Sentiment done", f"{result['positive_pct']}% positive · {result['negative_pct']}% negative")

        step("🔑 Extracting keywords", "Finding top terms across all posts…")
        keywords = extract_keywords(cleaned, top_n=20)
        result["keywords"] = keywords
        top_kws = ", ".join(w for w, _ in keywords[:5])
        step("✅ Keywords extracted", f"Top: {top_kws}")

        step("📋 Generating summary", "Calculating sentiment distribution…")
        summary = generate_summary(sentiment_results)
        result["summary"] = summary
        step("✅ Summary ready")

        step("📊 Google Trends", "Fetching interest over time & related queries…")
        trends_data = get_trends_data(topic)
        result["trends"] = trends_data
        trends_status = "No data" if trends_data.get("error") else f"{len(trends_data.get('top_queries', []))} related queries"
        step("✅ Trends fetched", trends_status)

        step("💡 Gemini Insights", "Asking Gemini to analyse sentiment data…")
        insights = generate_insights(topic, summary, keywords, sentiment_results)
        result["insights"] = insights
        step("✅ Insights ready")

        step("🎯 Recommendations", "Generating strategic action items…")
        recommendations = generate_recommendations(topic, insights, sentiment_results)
        result["recommendations"] = recommendations
        step("✅ Recommendations ready", f"{len(recommendations)} actions generated")

        step("🚨 Alerts", "Checking for anomalies and signals…")
        alerts = generate_alerts(topic, sentiment_results, keywords)
        result["alerts"] = alerts
        high = sum(1 for a in alerts if a["severity"] == "High")
        step("✅ Pipeline complete", f"{len(alerts)} alerts · {high} high-severity")

    except Exception as e:
        result["error"] = str(e)
        result["alerts"] = [{"severity": "High", "message": f"Pipeline error: {str(e)}", "type": "System"}]
        step("❌ Pipeline error", str(e))

    return result

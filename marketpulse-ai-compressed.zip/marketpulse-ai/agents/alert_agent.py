def generate_alerts(topic: str, sentiment_results: list, keywords: list) -> list:
    alerts = []

    if not sentiment_results:
        alerts.append({
            "severity": "High",
            "message": f"No data collected for '{topic}'. Check Reddit and Google News API connections.",
            "type": "Data",
        })
        return alerts

    total = len(sentiment_results)
    pos = sum(1 for r in sentiment_results if r["sentiment"] == "Positive")
    neg = total - pos
    pos_pct = (pos / total) * 100 if total > 0 else 0
    neg_pct = (neg / total) * 100 if total > 0 else 0

    if neg_pct >= 70:
        alerts.append({
            "severity": "High",
            "message": f"Critical negative sentiment: {neg_pct:.1f}% of {total} posts about '{topic}' are negative. Immediate review recommended.",
            "type": "Sentiment",
        })
    elif neg_pct >= 50:
        alerts.append({
            "severity": "Medium",
            "message": f"Majority negative: {neg_pct:.1f}% negative sentiment detected across {total} posts for '{topic}'.",
            "type": "Sentiment",
        })
    elif pos_pct >= 75:
        alerts.append({
            "severity": "Low",
            "message": f"Strong positive signal: {pos_pct:.1f}% positive sentiment across {total} posts for '{topic}'.",
            "type": "Opportunity",
        })

    if total < 10:
        alerts.append({
            "severity": "Medium",
            "message": f"Low sample size: Only {total} posts collected. Increase post limit for more reliable results.",
            "type": "Data",
        })
    elif total >= 100:
        alerts.append({
            "severity": "Low",
            "message": f"High volume signal: {total} posts analyzed — results have strong statistical confidence.",
            "type": "Data",
        })

    if keywords:
        top_word, top_count = keywords[0]
        concentration = (top_count / total) * 100 if total > 0 else 0
        if concentration > 40:
            alerts.append({
                "severity": "Low",
                "message": f"Topic concentration: '{top_word}' appears in {top_count} posts ({concentration:.0f}%). Narrow audience detected.",
                "type": "Trend",
            })

    if not alerts:
        alerts.append({
            "severity": "Low",
            "message": f"All clear: Sentiment for '{topic}' is balanced ({pos_pct:.1f}% positive). No anomalies detected.",
            "type": "Status",
        })

    return alerts

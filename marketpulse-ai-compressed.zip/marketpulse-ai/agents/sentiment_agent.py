import joblib
import os

_BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
model = joblib.load(os.path.join(_BASE, "models", "model.pkl"))
vectorizer = joblib.load(os.path.join(_BASE, "models", "vectorizer.pkl"))


def predict_sentiment(tweet):
    vector = vectorizer.transform([tweet])
    prediction = model.predict(vector)[0]
    return "Positive" if prediction == 1 else "Negative"


def analyze_tweets(tweets):
    return [{"tweet": t, "sentiment": predict_sentiment(t)} for t in tweets]

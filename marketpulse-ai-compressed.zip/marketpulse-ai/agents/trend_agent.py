from collections import Counter
import re


def extract_keywords(tweets, top_n=10):

    words = []

    for tweet in tweets:

        tweet_words = re.findall(
            r"\b[a-zA-Z]{4,}\b",
            tweet.lower()
        )

        words.extend(tweet_words)

    counter = Counter(words)

    return counter.most_common(top_n)


if __name__ == "__main__":

    tweets = [
        "AI is changing education",
        "AI is changing business",
        "Business uses AI"
    ]

    print(extract_keywords(tweets))

import sys
import os
import re
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config import GEMINI_API_KEY

try:
    from google import genai
    _GENAI_AVAILABLE = True
except ImportError:
    _GENAI_AVAILABLE = False


def _key_valid(key: str) -> bool:
    return bool(key) and not key.startswith("your_") and len(key) > 10


def generate_recommendations(topic: str, insights: str, sentiment_results: list) -> list:
    if not _GENAI_AVAILABLE or not _key_valid(GEMINI_API_KEY):
        return [{"action": "Add your real GEMINI_API_KEY to .env to enable AI recommendations.", "priority": "High", "category": "Setup"}]

    try:
        client = genai.Client(api_key=GEMINI_API_KEY)
        model = "gemini-2.0-flash"

        pos = sum(1 for r in sentiment_results if r["sentiment"] == "Positive")
        total = len(sentiment_results)
        pos_pct = round((pos / total) * 100, 1) if total > 0 else 0

        prompt = f"""You are a strategic business advisor. Based on sentiment analysis of "{topic}" ({pos_pct}% positive, {total} posts):

Key Insights: {insights[:600]}

Generate exactly 6 actionable recommendations. Use this exact format for each line:
[High|Medium|Low] | [Category] | Recommendation text here.

Categories must be one of: Content, Product, Risk, Opportunity, PR, Research

Example:
[High] | [Risk] | Monitor negative sentiment spikes with daily alerts.
[Medium] | [Content] | Create educational content addressing common concerns.

Output only the 6 lines, no extra text."""

        response = client.models.generate_content(model=model, contents=prompt)
        recs = []
        for line in response.text.strip().split("\n"):
            line = line.strip()
            if not line:
                continue

            priority = "Medium"
            if "High" in line:
                priority = "High"
            elif "Low" in line:
                priority = "Low"

            category = "General"
            cat_match = re.search(r"\[([A-Za-z]+)\]", line)
            if cat_match:
                cats = re.findall(r"\[([A-Za-z]+)\]", line)
                for c in cats:
                    if c not in ("High", "Medium", "Low"):
                        category = c
                        break

            text = re.sub(r"\[(High|Medium|Low)\]\s*\|\s*", "", line)
            text = re.sub(r"\[[A-Za-z]+\]\s*\|?\s*", "", text).strip()

            if text:
                recs.append({"action": text, "priority": priority, "category": category})

        return recs if recs else [{"action": response.text, "priority": "Medium", "category": "General"}]

    except Exception as e:
        return [{"action": f"Recommendation generation failed: {str(e)}", "priority": "Low", "category": "Error"}]

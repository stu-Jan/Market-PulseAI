import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config import GEMINI_API_KEY

try:
    from google import genai
    _GENAI_AVAILABLE = True
except ImportError:
    _GENAI_AVAILABLE = False


def _key_valid(key: str) -> bool:
    return bool(key) and not key.startswith("your_") and len(key) > 10


def generate_insights(topic: str, summary: str, keywords: list, sentiment_results: list) -> str:
    if not _GENAI_AVAILABLE:
        return "google-genai not installed. Run: pip install google-genai"

    if not _key_valid(GEMINI_API_KEY):
        return "⚠️ Add your real GEMINI_API_KEY to the .env file to enable AI insights."

    try:
        client = genai.Client(api_key=GEMINI_API_KEY)
        model = "gemini-2.0-flash"

        pos = sum(1 for r in sentiment_results if r["sentiment"] == "Positive")
        neg = len(sentiment_results) - pos
        total = len(sentiment_results)
        pos_pct = round((pos / total) * 100, 1) if total > 0 else 0
        keyword_str = ", ".join(f"{w}({c})" for w, c in keywords[:15])

        prompt = f"""You are a senior market intelligence analyst. Analyze public sentiment data about "{topic}".

METRICS:
- Total posts analyzed: {total}
- Positive: {pos} ({pos_pct}%) | Negative: {neg} ({100 - pos_pct}%)
- Top keywords: {keyword_str}

SUMMARY:
{summary}

Provide structured insights using EXACTLY these sections with markdown headers:

## Overall Sentiment Landscape
2-3 sentences on the current sentiment climate.

## Key Themes
- 4 bullet points on dominant discussion themes

## Public Perception
2-3 sentences on how the public views this topic.

## Market Signals
- 3 bullet points on actionable market signals

## Risk Factors
- 3 bullet points on risks or concerns

Be specific, data-driven, and concise. Reference the actual numbers."""

        response = client.models.generate_content(model=model, contents=prompt)
        return response.text

    except Exception as e:
        return f"Insight generation failed: {str(e)}"

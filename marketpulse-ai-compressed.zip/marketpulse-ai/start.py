"""Start MarketPulse AI — FastAPI backend + React frontend."""
import subprocess, sys, os, time, webbrowser

ROOT = os.path.dirname(os.path.abspath(__file__))

def run():
    print("\n📡 MarketPulse AI — Starting...\n")

    # Start FastAPI backend
    backend = subprocess.Popen(
        [sys.executable, "-m", "uvicorn", "api.main:app",
         "--host", "0.0.0.0", "--port", "8000", "--reload"],
        cwd=ROOT,
    )
    print("✅ Backend  → http://localhost:8000")

    # Start Vite dev server
    frontend = subprocess.Popen(
        ["npm", "run", "dev"],
        cwd=os.path.join(ROOT, "frontend"),
        shell=True,
    )
    print("✅ Frontend → http://localhost:5173")
    print("\nPress Ctrl+C to stop both servers.\n")

    time.sleep(2)
    webbrowser.open("http://localhost:5173")

    try:
        backend.wait()
    except KeyboardInterrupt:
        print("\nStopping...")
        backend.terminate()
        frontend.terminate()

if __name__ == "__main__":
    run()

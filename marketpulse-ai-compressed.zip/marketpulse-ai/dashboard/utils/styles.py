GLOBAL_CSS = """
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap');

/* ─── Reset ─────────────────────────────────────────────────── */
*, *::before, *::after { box-sizing: border-box; }
html, body, [data-testid="stAppViewContainer"], .main {
    background: #050B18 !important;
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif !important;
}
.block-container { padding: 1.2rem 2rem 3rem !important; max-width: 100% !important; }
h1,h2,h3,h4,h5 { font-family: 'Inter', sans-serif !important; font-weight: 700 !important; }
p, span, div, label { font-family: 'Inter', sans-serif !important; }

::-webkit-scrollbar { width: 5px; height: 5px; }
::-webkit-scrollbar-track { background: #0A1020; }
::-webkit-scrollbar-thumb { background: #1E293B; border-radius: 3px; }
::-webkit-scrollbar-thumb:hover { background: #6366F1; }

/* ─── Sidebar ─────────────────────────────────────────────────── */
section[data-testid="stSidebar"] {
    background: linear-gradient(180deg, #030712 0%, #050B18 100%) !important;
    border-right: 1px solid rgba(99,102,241,0.15) !important;
    padding-top: 0 !important;
}
section[data-testid="stSidebar"] .block-container { padding: 1.5rem 1rem !important; }

/* ─── Streamlit component overrides ───────────────────────────── */
.stButton > button {
    border-radius: 10px !important;
    font-weight: 600 !important;
    font-size: 0.85rem !important;
    height: 2.6rem !important;
    transition: all 0.2s cubic-bezier(0.4,0,0.2,1) !important;
}
.stButton > button[kind="primary"] {
    background: linear-gradient(135deg, #6366F1 0%, #8B5CF6 100%) !important;
    border: none !important;
    color: #fff !important;
    box-shadow: 0 4px 14px rgba(99,102,241,0.35) !important;
    letter-spacing: 0.02em !important;
}
.stButton > button[kind="primary"]:hover {
    transform: translateY(-2px) !important;
    box-shadow: 0 6px 20px rgba(99,102,241,0.5) !important;
}
.stButton > button[kind="secondary"] {
    background: rgba(30,41,59,0.8) !important;
    border: 1px solid rgba(99,102,241,0.3) !important;
    color: #A5B4FC !important;
}
.stTextInput > div > div > input {
    background: rgba(10,16,32,0.9) !important;
    border: 1px solid rgba(51,65,85,0.7) !important;
    border-radius: 10px !important;
    color: #F1F5F9 !important;
    font-size: 0.88rem !important;
    padding: 0.55rem 0.85rem !important;
}
.stTextInput > div > div > input:focus {
    border-color: rgba(99,102,241,0.6) !important;
    box-shadow: 0 0 0 2px rgba(99,102,241,0.15) !important;
}
.stSelectbox > div > div {
    background: rgba(10,16,32,0.9) !important;
    border: 1px solid rgba(51,65,85,0.7) !important;
    border-radius: 10px !important;
    color: #F1F5F9 !important;
}
.stSlider > div { padding: 0 0.3rem !important; }
.stSlider [data-baseweb="slider"] { padding: 0.3rem 0 !important; }

.stStatus {
    background: rgba(10,16,32,0.95) !important;
    border: 1px solid rgba(99,102,241,0.25) !important;
    border-radius: 14px !important;
}
.stDataFrame { border-radius: 12px !important; overflow: hidden !important; border: 1px solid rgba(51,65,85,0.4) !important; }
div[data-testid="column"] { padding: 0 0.4rem !important; }
.stDivider { border-color: rgba(51,65,85,0.4) !important; }
[data-testid="stMetricValue"] { color: #F1F5F9 !important; font-weight: 700 !important; }
[data-baseweb="tab-highlight"] { background: #6366F1 !important; }
[data-baseweb="tab-list"] { background: rgba(10,16,32,0.8) !important; border-radius: 10px !important; }

/* ─── Page header ─────────────────────────────────────────────── */
.mp-hero {
    background: linear-gradient(135deg, rgba(26,16,64,0.8) 0%, rgba(13,26,58,0.8) 50%, rgba(10,22,40,0.8) 100%);
    border: 1px solid rgba(99,102,241,0.2);
    border-radius: 20px;
    padding: 1.8rem 2.2rem;
    margin-bottom: 1.4rem;
    position: relative;
    overflow: hidden;
}
.mp-hero::after {
    content: '';
    position: absolute; inset: 0;
    background:
        radial-gradient(ellipse at 15% 50%, rgba(99,102,241,0.10) 0%, transparent 55%),
        radial-gradient(ellipse at 85% 30%, rgba(6,182,212,0.07) 0%, transparent 50%);
    pointer-events: none;
    animation: heroGlow 10s ease-in-out infinite alternate;
}
@keyframes heroGlow {
    0%  { opacity: 0.7; }
    100%{ opacity: 1.0; }
}
.mp-hero-title, h1.mp-hero-title {
    display: block;
    font-size: 2rem; font-weight: 900;
    background: linear-gradient(120deg, #FFFFFF 0%, #C7D2FE 40%, #67E8F9 100%);
    -webkit-background-clip: text; -webkit-text-fill-color: transparent;
    background-clip: text; margin: 0; line-height: 1.15;
}
.mp-hero-sub { color: #64748B; font-size: 0.85rem; margin-top: 0.35rem; font-weight: 400; }
.mp-hero-badge {
    position: absolute; top: 1.4rem; right: 1.6rem;
    background: rgba(16,185,129,0.12); color: #10FDAA;
    border: 1px solid rgba(16,185,129,0.3);
    border-radius: 999px; padding: 0.25rem 0.85rem;
    font-size: 0.72rem; font-weight: 700; letter-spacing: 0.05em;
}
.mp-hero-stats { display: flex; gap: 1.8rem; margin-top: 1rem; }
.mp-hero-stat-val { font-size: 1.4rem; font-weight: 800; color: #F1F5F9; line-height: 1; }
.mp-hero-stat-lbl { font-size: 0.7rem; color: #64748B; text-transform: uppercase; letter-spacing: 0.08em; margin-top: 0.2rem; }

/* ─── KPI Grid ─────────────────────────────────────────────────── */
.kpi-grid { display: grid; grid-template-columns: repeat(6, 1fr); gap: 0.85rem; margin: 1rem 0 1.4rem; }
@media (max-width: 1200px) { .kpi-grid { grid-template-columns: repeat(3, 1fr); } }

.kpi-card {
    background: rgba(10,16,32,0.7);
    backdrop-filter: blur(20px);
    border: 1px solid rgba(51,65,85,0.5);
    border-radius: 14px;
    padding: 1.1rem 0.9rem 1rem;
    text-align: center;
    position: relative;
    overflow: hidden;
    cursor: default;
    animation: fadeUp 0.5s ease both;
    transition: transform 0.25s cubic-bezier(0.4,0,0.2,1), border-color 0.25s, box-shadow 0.25s;
}
.kpi-card::before {
    content: '';
    position: absolute; top: 0; left: 0; right: 0;
    height: 2.5px; border-radius: 14px 14px 0 0;
}
.kpi-card.c-blue::before   { background: linear-gradient(90deg,#06B6D4,#3B82F6); }
.kpi-card.c-green::before  { background: linear-gradient(90deg,#10FDAA,#06D6A0); }
.kpi-card.c-red::before    { background: linear-gradient(90deg,#FF4757,#FF6B9D); }
.kpi-card.c-purple::before { background: linear-gradient(90deg,#8B5CF6,#6366F1); }
.kpi-card.c-amber::before  { background: linear-gradient(90deg,#F59E0B,#F97316); }
.kpi-card.c-cyan::before   { background: linear-gradient(90deg,#22D3EE,#06B6D4); }
.kpi-card:hover {
    transform: translateY(-5px) scale(1.01);
    border-color: rgba(99,102,241,0.45);
    box-shadow: 0 12px 30px rgba(99,102,241,0.12);
}
.kpi-card:nth-child(1){animation-delay:.05s} .kpi-card:nth-child(2){animation-delay:.1s}
.kpi-card:nth-child(3){animation-delay:.15s} .kpi-card:nth-child(4){animation-delay:.2s}
.kpi-card:nth-child(5){animation-delay:.25s} .kpi-card:nth-child(6){animation-delay:.3s}

.kpi-icon { font-size:1.3rem; margin-bottom:0.3rem; }
.kpi-lbl  { font-size:0.63rem; color:#94A3B8; text-transform:uppercase; letter-spacing:0.09em; font-weight:600; margin-bottom:0.35rem; }
.kpi-val  { font-size:1.85rem; font-weight:800; line-height:1.05; }
.kpi-val.c-blue   { color:#38BDF8; text-shadow:0 0 18px rgba(56,189,248,0.35); }
.kpi-val.c-green  { color:#10FDAA; text-shadow:0 0 18px rgba(16,253,170,0.35); }
.kpi-val.c-red    { color:#FF4757; text-shadow:0 0 18px rgba(255,71,87,0.35); }
.kpi-val.c-purple { color:#A78BFA; text-shadow:0 0 18px rgba(167,139,250,0.35); }
.kpi-val.c-amber  { color:#FCD34D; text-shadow:0 0 18px rgba(252,211,77,0.35); }
.kpi-val.c-cyan   { color:#67E8F9; text-shadow:0 0 18px rgba(103,232,249,0.35); }
.kpi-delta { font-size:0.68rem; color:#718096; margin-top:0.25rem; }

/* ─── Section header ──────────────────────────────────────────── */
.sec-hdr {
    display:flex; align-items:center; gap:0.55rem;
    font-size:0.72rem; font-weight:700; color:#94A3B8;
    text-transform:uppercase; letter-spacing:0.12em;
    margin:1.8rem 0 0.85rem;
    padding-bottom:0.55rem;
    border-bottom:1px solid rgba(51,65,85,0.45);
}
.sec-hdr-bar {
    width:3px; height:14px;
    background:linear-gradient(180deg,#6366F1,#06B6D4);
    border-radius:2px; flex-shrink:0;
}

/* ─── Glass card ──────────────────────────────────────────────── */
.glass {
    background: rgba(10,16,32,0.55);
    backdrop-filter: blur(24px);
    border: 1px solid rgba(51,65,85,0.45);
    border-radius: 16px;
    padding: 1.35rem 1.5rem;
    margin: 0.5rem 0;
    transition: border-color 0.2s;
    animation: fadeUp 0.4s ease both;
}
.glass:hover { border-color: rgba(99,102,241,0.3); }

/* ─── Alert cards ─────────────────────────────────────────────── */
.a-card {
    display:flex; align-items:flex-start; gap:0.8rem;
    border-radius:13px; padding:0.95rem 1.1rem; margin:0.45rem 0;
    animation: fadeLeft 0.35s ease both;
}
.a-card.high   { background:rgba(127,29,29,0.25);  border:1px solid rgba(220,38,38,0.4); }
.a-card.medium { background:rgba(120,53,15,0.25);  border:1px solid rgba(249,115,22,0.4); }
.a-card.low    { background:rgba(6,78,59,0.22);    border:1px solid rgba(16,185,129,0.4); }
.a-sev-badge {
    font-size:0.65rem; font-weight:700; padding:0.18rem 0.55rem;
    border-radius:999px; white-space:nowrap; flex-shrink:0; margin-top:0.15rem;
}
.a-sev-badge.high   { background:rgba(220,38,38,0.2);  color:#FCA5A5; }
.a-sev-badge.medium { background:rgba(249,115,22,0.2); color:#FED7AA; }
.a-sev-badge.low    { background:rgba(16,185,129,0.2); color:#6EE7B7; }
.a-text { font-size:0.88rem; color:#CBD5E1; line-height:1.6; }
.a-type { font-size:0.7rem; color:#718096; margin-top:0.15rem; }

/* ─── Badges ──────────────────────────────────────────────────── */
.bdg { display:inline-flex; align-items:center; gap:0.3rem; padding:0.18rem 0.65rem; border-radius:999px; font-size:0.68rem; font-weight:700; }
.bdg-high   { background:rgba(127,29,29,0.4);  color:#FCA5A5; border:1px solid rgba(220,38,38,0.35); }
.bdg-medium { background:rgba(120,53,15,0.4);  color:#FCD34D; border:1px solid rgba(249,115,22,0.35); }
.bdg-low    { background:rgba(6,78,59,0.4);    color:#6EE7B7; border:1px solid rgba(16,185,129,0.35); }
.bdg-cat    { background:rgba(99,102,241,0.15); color:#A5B4FC; border:1px solid rgba(99,102,241,0.3); }

/* ─── Status panel ────────────────────────────────────────────── */
.status-item {
    display:flex; align-items:center; gap:0.65rem;
    padding:0.55rem 0.7rem; border-radius:10px; margin:0.25rem 0;
    transition:background 0.2s;
}
.status-item:hover { background:rgba(30,41,59,0.4); }
.s-dot { width:8px; height:8px; border-radius:50%; flex-shrink:0; }
.s-dot.on  { background:#10B981; box-shadow:0 0 7px rgba(16,185,129,0.7); animation:pulse 2s infinite; }
.s-dot.off { background:#374151; }
.s-name  { flex:1; font-size:0.83rem; font-weight:600; color:#CBD5E1; }
.s-label { font-size:0.72rem; }
.s-label.on  { color:#10B981; }
.s-label.off { color:#718096; }

/* ─── Rec card ────────────────────────────────────────────────── */
.rec-card {
    display:flex; gap:0.9rem; align-items:flex-start;
    background:rgba(10,16,32,0.55); border:1px solid rgba(51,65,85,0.45);
    border-radius:14px; padding:1.05rem 1.2rem; margin:0.45rem 0;
    transition:all 0.22s cubic-bezier(0.4,0,0.2,1);
    animation:fadeUp 0.4s ease both;
}
.rec-card:hover { border-color:rgba(99,102,241,0.4); transform:translateX(4px); box-shadow:0 4px 20px rgba(99,102,241,0.1); }
.rec-ico { font-size:1.4rem; line-height:1; padding-top:0.05rem; flex-shrink:0; }
.rec-bdgs { display:flex; gap:0.35rem; flex-wrap:wrap; margin-bottom:0.45rem; }
.rec-txt  { font-size:0.88rem; color:#CBD5E1; line-height:1.65; }

/* ─── Keyword chips ───────────────────────────────────────────── */
.kw-chip {
    display:inline-flex; align-items:center; gap:0.3rem;
    background:rgba(99,102,241,0.08); color:#A5B4FC;
    border:1px solid rgba(99,102,241,0.18); border-radius:999px;
    padding:0.22rem 0.75rem; margin:0.2rem;
    font-size:0.78rem; font-weight:500;
    transition:all 0.18s;
}
.kw-chip:hover { background:rgba(99,102,241,0.2); border-color:rgba(99,102,241,0.45); }
.kw-n { color:#6366F1; font-weight:700; font-size:0.72rem; }

/* ─── Insight section ─────────────────────────────────────────── */
.ins-card {
    background:rgba(10,16,32,0.5); border:1px solid rgba(51,65,85,0.4);
    border-radius:16px; padding:1.3rem 1.5rem; margin:0.65rem 0;
    animation:fadeUp 0.45s ease both;
}
.ins-card:hover { border-color:rgba(99,102,241,0.3); }
.ins-title { font-size:0.95rem; font-weight:700; color:#A78BFA; margin-bottom:0.65rem; display:flex; align-items:center; gap:0.5rem; }
.ins-body  { font-size:0.875rem; color:#CBD5E1; line-height:1.78; }
.ins-body ul { padding-left:1.1rem; margin:0.35rem 0; }
.ins-body li { margin-bottom:0.3rem; }
.ins-body strong { color:#F1F5F9; }

/* ─── Landing ─────────────────────────────────────────────────── */
.landing-wrap { text-align:center; padding:4rem 2rem; }
.landing-icon { font-size:5rem; animation:floatIcon 3s ease-in-out infinite; }
.landing-title { font-size:1.9rem; font-weight:800; color:#CBD5E1; margin:1rem 0 0.5rem; }
.landing-sub { color:#718096; font-size:1rem; line-height:1.7; max-width:520px; margin:0 auto 2rem; }
@keyframes floatIcon {
    0%,100%{ transform:translateY(0); }
    50%     { transform:translateY(-10px); }
}

.topic-pill {
    display:inline-block; background:rgba(99,102,241,0.08);
    border:1px solid rgba(99,102,241,0.2); border-radius:999px;
    padding:0.45rem 1.2rem; margin:0.3rem; color:#A5B4FC;
    font-size:0.85rem; font-weight:500; cursor:pointer;
    transition:all 0.2s;
}
.topic-pill:hover { background:rgba(99,102,241,0.2); border-color:rgba(99,102,241,0.5); transform:translateY(-2px); }

/* ─── Live pill ───────────────────────────────────────────────── */
.live-pill {
    display:inline-flex; align-items:center; gap:0.4rem;
    background:rgba(16,185,129,0.1); color:#10FDAA;
    border:1px solid rgba(16,185,129,0.3); border-radius:999px;
    padding:0.22rem 0.75rem; font-size:0.7rem; font-weight:700; letter-spacing:0.05em;
}
.live-dot { width:6px; height:6px; background:#10FDAA; border-radius:50%; animation:pulse 1.2s infinite; }

/* ─── Animations ──────────────────────────────────────────────── */
@keyframes fadeUp {
    from { opacity:0; transform:translateY(14px); }
    to   { opacity:1; transform:translateY(0); }
}
@keyframes fadeLeft {
    from { opacity:0; transform:translateX(-10px); }
    to   { opacity:1; transform:translateX(0); }
}
@keyframes pulse {
    0%,100%{ opacity:1; }
    50%    { opacity:0.35; }
}
@keyframes borderSpin {
    from { transform:rotate(0deg); }
    to   { transform:rotate(360deg); }
}

/* ─── Sidebar branding ────────────────────────────────────────── */
.sb-logo {
    font-size:1.35rem; font-weight:900; letter-spacing:-0.02em;
    background:linear-gradient(120deg,#A5B4FC,#67E8F9);
    -webkit-background-clip:text; -webkit-text-fill-color:transparent;
    background-clip:text;
}
.sb-tagline { font-size:0.72rem; color:#718096; margin-top:-0.1rem; margin-bottom:0.8rem; }
.sb-section { font-size:0.65rem; font-weight:700; color:#718096; text-transform:uppercase; letter-spacing:0.12em; margin:1rem 0 0.4rem; }
</style>
"""


PLOTLY_LAYOUT = dict(
    paper_bgcolor="rgba(0,0,0,0)",
    plot_bgcolor="rgba(0,0,0,0)",
    font=dict(family="Inter, sans-serif", color="#94A3B8", size=12),
    margin=dict(t=48, b=32, l=32, r=24),
    xaxis=dict(gridcolor="rgba(51,65,85,0.35)", linecolor="rgba(51,65,85,0.5)", tickfont=dict(color="#64748B")),
    yaxis=dict(gridcolor="rgba(51,65,85,0.35)", linecolor="rgba(51,65,85,0.5)", tickfont=dict(color="#64748B")),
    legend=dict(bgcolor="rgba(10,16,32,0.7)", bordercolor="rgba(51,65,85,0.4)", borderwidth=1, font=dict(color="#94A3B8")),
    title=dict(font=dict(color="#CBD5E1", size=14), x=0),
)

NEON = dict(
    positive="#10FDAA",
    negative="#FF4757",
    blue="#38BDF8",
    purple="#A78BFA",
    indigo="#818CF8",
    cyan="#67E8F9",
    amber="#FCD34D",
    pink="#F472B6",
)

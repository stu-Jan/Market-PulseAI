import pandas as pd
import io


def results_to_dataframe(results: dict) -> pd.DataFrame:
    rows = []
    for r in results.get("sentiment_results", []):
        rows.append({
            "Source":    r.get("source", ""),
            "Text":      r.get("original_text", r.get("tweet", "")),
            "Sentiment": r.get("sentiment", ""),
            "Created":   r.get("created", ""),
            "URL":       r.get("url", ""),
        })
    df = pd.DataFrame(rows)
    # Drop exact duplicates (same URL + same text)
    if not df.empty and "URL" in df.columns:
        df = df.drop_duplicates(subset=["URL", "Text"]).reset_index(drop=True)
    return df


def to_csv_bytes(df: pd.DataFrame) -> bytes:
    return df.to_csv(index=False).encode("utf-8")


def to_excel_bytes(df: pd.DataFrame) -> bytes:
    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine="openpyxl") as writer:
        df.to_excel(writer, index=False, sheet_name="MarketPulse Results")
    return buf.getvalue()

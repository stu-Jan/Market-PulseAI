import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

import streamlit as st
import plotly.graph_objects as go
from collections import Counter

st.set_page_config(page_title="Alerts & Signals · MarketPulse AI — Anomaly Detection", page_icon="🚨", layout="wide")

from dashboard.components.sidebar import inject_css, render_sidebar
from dashboard.utils.styles import PLOTLY_LAYOUT, NEON
inject_css()

results = render_sidebar()

st.markdown('<div class="mp-hero" style="padding:1.4rem 1.8rem">'
            '<h1 class="mp-hero-title" style="font-size:1.5rem">🚨 Alerts</h1>'
            '<div class="mp-hero-sub">Automated anomaly detection · Sentiment signals · Data quality</div>'
            '</div>', unsafe_allow_html=True)

if not results:
    st.info("Enter a topic and click **Analyze Now** in the sidebar.")
    st.stop()

alerts = results.get("alerts", [])
if not alerts:
    st.markdown('<div class="glass" style="text-align:center;color:#10B981;padding:2.5rem;font-size:1rem">✅ No alerts — all systems normal</div>', unsafe_allow_html=True)
    st.stop()

high   = [a for a in alerts if a["severity"] == "High"]
medium = [a for a in alerts if a["severity"] == "Medium"]
low    = [a for a in alerts if a["severity"] == "Low"]

# ── Summary ────────────────────────────────────────────────────────────────────
c1, c2, c3, c4 = st.columns(4)
for col, lbl, n, color in [
    (c1,"Total",      len(alerts), NEON["blue"]),
    (c2,"🔴 Critical",len(high),   NEON["negative"]),
    (c3,"🟡 Warning", len(medium), NEON["amber"]),
    (c4,"🟢 Info",    len(low),    NEON["positive"]),
]:
    col.markdown(f'<div class="glass" style="text-align:center;padding:1rem">'
                 f'<div style="font-size:1.6rem;font-weight:800;color:{color}">{n}</div>'
                 f'<div style="font-size:.65rem;color:#64748B;text-transform:uppercase;letter-spacing:.08em;margin-top:.2rem">{lbl}</div>'
                 f'</div>', unsafe_allow_html=True)

# ── Type donut ──────────────────────────────────────────────────────────────────
if len(alerts) > 1:
    tc = Counter(a.get("type","General") for a in alerts)
    fig = go.Figure(go.Pie(
        labels=list(tc.keys()), values=list(tc.values()), hole=0.55,
        marker=dict(
            colors=[NEON["negative"],NEON["amber"],NEON["blue"],NEON["purple"],NEON["positive"]],
            line=dict(color="#050B18",width=2),
        ),
        textinfo="label+percent",
        hovertemplate="<b>%{label}</b><br>%{value} alert(s)<extra></extra>",
    ))
    fig.update_layout(**PLOTLY_LAYOUT, title="Alerts by Type", height=260,
                      margin=dict(t=40,b=10,l=0,r=0))
    fc, _ = st.columns([1,2])
    with fc:
        st.plotly_chart(fig, use_container_width=True)

type_icons = {"Sentiment":"💬","Data":"🗃","Trend":"📊","Opportunity":"🚀","System":"⚙️","Status":"✅"}
sev_ico    = {"High":"🔴","Medium":"🟡","Low":"🟢"}

def render_section(lst, title):
    if not lst: return
    st.markdown(f'<div class="sec-hdr"><div class="sec-hdr-bar"></div>{title}</div>', unsafe_allow_html=True)
    for i, a in enumerate(lst):
        sev = a["severity"].lower()
        t   = a.get("type","General")
        st.markdown(f"""<div class="a-card {sev}" style="animation-delay:{i*0.07}s">
            <span class="a-sev-badge {sev}">{sev_ico.get(a['severity'],'•')} {a['severity']}</span>
            <div>
                <div class="a-text">{a['message']}</div>
                <div class="a-type">{type_icons.get(t,'ℹ️')} {t}</div>
            </div>
        </div>""", unsafe_allow_html=True)

render_section(high,   "🔴 Critical Alerts")
render_section(medium, "🟡 Warning Alerts")
render_section(low,    "🟢 Info & Signals")

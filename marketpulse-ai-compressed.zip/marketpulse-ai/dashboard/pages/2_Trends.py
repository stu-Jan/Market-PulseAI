import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

import streamlit as st
import plotly.graph_objects as go
import pandas as pd

st.set_page_config(page_title="Trends & Keywords · MarketPulse AI — Google Trends Analysis", page_icon="📈", layout="wide")

from dashboard.components.sidebar import inject_css, render_sidebar
from dashboard.utils.styles import PLOTLY_LAYOUT, NEON
inject_css()

results = render_sidebar()

st.markdown('<div class="mp-hero" style="padding:1.4rem 1.8rem">'
            '<h1 class="mp-hero-title" style="font-size:1.5rem">📈 Trends & Keywords</h1>'
            '<div class="mp-hero-sub">Top keywords from posts · Google Trends interest · Related & rising queries</div>'
            '</div>', unsafe_allow_html=True)

if not results:
    st.info("Enter a topic and click **Analyze Now** in the sidebar.")
    st.stop()

keywords = results.get("keywords", [])
trends   = results.get("trends", {})
topic    = results.get("topic", "")

# ─── Keywords ──────────────────────────────────────────────────────────────────
st.markdown('<div class="sec-hdr"><div class="sec-hdr-bar"></div>Top Keywords from Posts</div>', unsafe_allow_html=True)

if keywords:
    kw_df = pd.DataFrame(keywords, columns=["Keyword","Count"])
    col_cloud, col_bar = st.columns([1,2])

    with col_cloud:
        st.markdown("**Keyword Cloud**")
        max_c = kw_df["Count"].max()
        html = ""
        for _, row in kw_df.head(20).iterrows():
            sz = 0.72 + 0.32 * (row["Count"] / max_c)
            html += f'<span class="kw-chip" style="font-size:{sz:.2f}rem">{row["Keyword"]} <span class="kw-n">{row["Count"]}</span></span>'
        st.markdown(html, unsafe_allow_html=True)

    with col_bar:
        fig = go.Figure(go.Bar(
            y=kw_df["Keyword"].head(15), x=kw_df["Count"].head(15), orientation="h",
            marker=dict(
                color=kw_df["Count"].head(15),
                colorscale=[[0,"#1E293B"],[0.5,"#6366F1"],[1,"#06B6D4"]],
                showscale=False, line=dict(width=0),
            ),
            text=kw_df["Count"].head(15), textposition="outside",
            textfont=dict(color="#94A3B8", size=11),
        ))
        fig.update_layout(**PLOTLY_LAYOUT, title="Keyword Frequency", height=420,
                          yaxis=dict(autorange="reversed", **PLOTLY_LAYOUT["yaxis"]),
                          xaxis_title="Occurrences")
        st.plotly_chart(fig, use_container_width=True)
else:
    st.markdown('<div class="glass" style="color:#64748B;text-align:center;padding:2rem">No keywords extracted yet.</div>', unsafe_allow_html=True)

# ─── Google Trends ──────────────────────────────────────────────────────────────
st.markdown('<div class="sec-hdr"><div class="sec-hdr-bar"></div>Google Trends — Interest Over Time (Last 7 Days)</div>', unsafe_allow_html=True)
idf = trends.get("interest_over_time")

if idf is not None and not idf.empty and topic in idf.columns:
    fig2 = go.Figure()
    fig2.add_trace(go.Scatter(
        x=idf.index, y=idf[topic], mode="lines+markers",
        name=topic,
        line=dict(color=NEON["indigo"], width=2.5),
        marker=dict(size=5, color=NEON["indigo"]),
        fill="tozeroy", fillcolor="rgba(99,102,241,0.1)",
        hovertemplate="<b>%{x}</b><br>Interest: %{y}<extra></extra>",
    ))
    fig2.update_layout(**PLOTLY_LAYOUT, title=f'Search Interest: "{topic}"',
                       height=310, yaxis_title="Interest (0–100)")
    st.plotly_chart(fig2, use_container_width=True)
elif trends.get("error"):
    st.markdown(f'<div class="glass" style="color:#64748B;text-align:center;padding:1.5rem">'
                f'⚠️ Google Trends unavailable — <code>{trends["error"][:100]}</code></div>',
                unsafe_allow_html=True)
else:
    st.markdown('<div class="glass" style="color:#64748B;text-align:center;padding:1.5rem">'
                'Google Trends data not available for this topic.</div>', unsafe_allow_html=True)

# ─── Related + Rising ──────────────────────────────────────────────────────────
c1, c2 = st.columns(2)

with c1:
    st.markdown('<div class="sec-hdr"><div class="sec-hdr-bar"></div>Top Related Queries</div>', unsafe_allow_html=True)
    tq = trends.get("top_queries", [])
    if tq:
        tdf = pd.DataFrame(tq)
        tdf.columns = [c.title() for c in tdf.columns]
        st.dataframe(tdf, use_container_width=True, hide_index=True, height=260)
    else:
        st.markdown('<div class="glass" style="color:#64748B;text-align:center;padding:1.5rem">No related queries.</div>', unsafe_allow_html=True)

with c2:
    st.markdown('<div class="sec-hdr"><div class="sec-hdr-bar"></div>Rising Queries</div>', unsafe_allow_html=True)
    rq = trends.get("rising_queries", [])
    if rq:
        rdf = pd.DataFrame(rq)
        rdf.columns = [c.title() for c in rdf.columns]
        st.dataframe(rdf, use_container_width=True, hide_index=True, height=260)
    else:
        st.markdown('<div class="glass" style="color:#64748B;text-align:center;padding:1.5rem">No rising queries.</div>', unsafe_allow_html=True)

# ─── Emerging ──────────────────────────────────────────────────────────────────
emerging = trends.get("emerging_topics", [])
if emerging:
    st.markdown('<div class="sec-hdr"><div class="sec-hdr-bar"></div>Emerging Topics</div>', unsafe_allow_html=True)
    icons = ["🚀","⚡","🌊","🔥","💎","🎯"]
    ecols = st.columns(len(emerging))
    for i, (col, t) in enumerate(zip(ecols, emerging)):
        col.markdown(f'<div class="glass" style="text-align:center;padding:1.1rem .6rem">'
                     f'<div style="font-size:1.5rem;margin-bottom:.4rem">{icons[i%len(icons)]}</div>'
                     f'<div style="font-size:.85rem;color:#CBD5E1;font-weight:600">{t}</div></div>',
                     unsafe_allow_html=True)

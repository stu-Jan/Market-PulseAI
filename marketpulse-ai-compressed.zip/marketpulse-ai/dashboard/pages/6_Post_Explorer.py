import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

import streamlit as st
import pandas as pd

st.set_page_config(page_title="Post Explorer · MarketPulse AI — Browse All Collected Posts", page_icon="🔍", layout="wide")

from dashboard.components.sidebar import inject_css, render_sidebar
from dashboard.utils.export import results_to_dataframe, to_csv_bytes, to_excel_bytes
inject_css()

results = render_sidebar()

st.markdown('<div class="mp-hero" style="padding:1.4rem 1.8rem">'
            '<h1 class="mp-hero-title" style="font-size:1.5rem">🔍 Post Explorer</h1>'
            '<div class="mp-hero-sub">Browse, search, filter and export every collected post · Click URLs to open originals</div>'
            '</div>', unsafe_allow_html=True)

if not results or not results.get("sentiment_results"):
    st.info("Enter a topic and click **Analyze Now** in the sidebar.")
    st.stop()

df = results_to_dataframe(results)

# ─── Filters ───────────────────────────────────────────────────────────────────
st.markdown('<div class="sec-hdr"><div class="sec-hdr-bar"></div>Filter & Search</div>', unsafe_allow_html=True)
f1, f2, f3 = st.columns([3,1,1])
with f1:
    q = st.text_input("search", placeholder="🔍  Search post text…", label_visibility="collapsed")
with f2:
    src_opts = ["All Sources"] + sorted(df["Source"].unique().tolist())
    src = st.selectbox("source", src_opts, label_visibility="collapsed")
with f3:
    sent_opts = ["All", "Positive", "Negative"]
    sent = st.selectbox("sentiment", sent_opts, label_visibility="collapsed")

out = df.copy()
if q:    out = out[out["Text"].str.contains(q, case=False, na=False)]
if src  != "All Sources": out = out[out["Source"] == src]
if sent != "All":         out = out[out["Sentiment"] == sent]

# ─── Stats ─────────────────────────────────────────────────────────────────────
pos_n = (out["Sentiment"] == "Positive").sum()
neg_n = (out["Sentiment"] == "Negative").sum()
pct   = round(pos_n / len(out) * 100, 1) if len(out) > 0 else 0

for col, lbl, val, color in zip(
    st.columns(5),
    ["Showing","Total","Positive","Negative","Positive Rate"],
    [len(out),len(df),pos_n,neg_n,f"{pct}%"],
    ["#38BDF8","#94A3B8","#10FDAA","#FF4757","#A78BFA"],
):
    col.markdown(f'<div class="glass" style="text-align:center;padding:.85rem">'
                 f'<div style="font-size:1.4rem;font-weight:800;color:{color}">{val}</div>'
                 f'<div style="font-size:.65rem;color:#64748B;text-transform:uppercase;letter-spacing:.08em;margin-top:.2rem">{lbl}</div>'
                 f'</div>', unsafe_allow_html=True)

# ─── Table with clickable URLs ──────────────────────────────────────────────────
st.markdown('<div class="sec-hdr"><div class="sec-hdr-bar"></div>Posts</div>', unsafe_allow_html=True)
sc1, sc2, _ = st.columns([1,1,4])
sort_col = sc1.selectbox("Sort", out.columns.tolist(), label_visibility="collapsed")
asc      = sc2.checkbox("Ascending", value=True)
out = out.sort_values(sort_col, ascending=asc).reset_index(drop=True)

def _hl(v):
    return ("background:#052e16;color:#10FDAA" if v == "Positive"
            else "background:#450a0a;color:#FF4757" if v == "Negative" else "")

try:
    styled = out.style.applymap(_hl, subset=["Sentiment"])
    st.dataframe(
        styled,
        use_container_width=True,
        height=520,
        column_config={
            "URL": st.column_config.LinkColumn("URL", display_text="Open ↗"),
        },
    )
except Exception:
    st.dataframe(out, use_container_width=True, height=520,
                 column_config={"URL": st.column_config.LinkColumn("URL", display_text="Open ↗")})

# ─── Export ─────────────────────────────────────────────────────────────────────
st.divider()
st.markdown('<div class="sec-hdr"><div class="sec-hdr-bar"></div>Export Filtered Results</div>', unsafe_allow_html=True)
slug = results["topic"].replace(" ","_")
ec1, ec2, _ = st.columns([1,1,5])
ec1.download_button("⬇ CSV",   to_csv_bytes(out),   f"posts_{slug}.csv",  "text/csv", use_container_width=True)
ec2.download_button("⬇ Excel", to_excel_bytes(out), f"posts_{slug}.xlsx", use_container_width=True)

import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

import streamlit as st
import plotly.graph_objects as go
import plotly.express as px
import pandas as pd

st.set_page_config(page_title="Sentiment Analysis · MarketPulse AI — Topic Sentiment Breakdown", page_icon="📊", layout="wide")

from dashboard.components.sidebar import inject_css, render_sidebar
from dashboard.utils.styles import PLOTLY_LAYOUT, NEON
inject_css()

results = render_sidebar()

st.markdown('<div class="mp-hero" style="padding:1.4rem 1.8rem">'
            '<h1 class="mp-hero-title" style="font-size:1.5rem">📊 Sentiment Analysis</h1>'
            '<div class="mp-hero-sub">ML-powered post classification · Positive vs Negative breakdown</div>'
            '</div>', unsafe_allow_html=True)

if not results or not results.get("sentiment_results"):
    st.info("Enter a topic and click **Analyze Now** in the sidebar.")
    st.stop()

sr  = results["sentiment_results"]
df  = pd.DataFrame(sr)
pos = (df["sentiment"] == "Positive").sum()
neg = (df["sentiment"] == "Negative").sum()
tot = len(df)

# ─── Row 1: Donut + Bar ────────────────────────────────────────────────────────
c1, c2 = st.columns(2)

with c1:
    fig = go.Figure(go.Pie(
        labels=["Positive","Negative"], values=[pos,neg], hole=0.62,
        marker=dict(colors=[NEON["positive"],NEON["negative"]], line=dict(color="#050B18",width=3)),
        textinfo="none",
        hovertemplate="<b>%{label}</b><br>%{value} posts · %{percent}<extra></extra>",
    ))
    fig.add_annotation(
        text=f"<b>{round(pos/tot*100,1)}%</b><br><span style='font-size:11px'>Positive</span>",
        x=0.5, y=0.5, font=dict(size=22, color=NEON["positive"]), showarrow=False,
    )
    fig.update_layout(**PLOTLY_LAYOUT, title="Sentiment Distribution", height=320,
                      showlegend=True, legend=dict(orientation="h",y=-0.08,x=0.5,xanchor="center"))
    st.plotly_chart(fig, use_container_width=True)

with c2:
    fig2 = go.Figure()
    for label, val, color in [("Positive", pos, NEON["positive"]), ("Negative", neg, NEON["negative"])]:
        fig2.add_trace(go.Bar(
            name=label, x=[label], y=[val],
            marker=dict(color=color, line=dict(width=0)),
            text=[f"{val}<br>{round(val/tot*100,1)}%"],
            textposition="outside", textfont=dict(color="#CBD5E1"), width=0.4,
        ))
    fig2.update_layout(**PLOTLY_LAYOUT, title="Post Count by Sentiment", height=320,
                       showlegend=False, yaxis_title="Posts", bargap=0.5)
    st.plotly_chart(fig2, use_container_width=True)

# ─── Row 2: By source ──────────────────────────────────────────────────────────
if "source" in df.columns and df["source"].nunique() > 0:
    st.markdown('<div class="sec-hdr"><div class="sec-hdr-bar"></div>Sentiment by Source</div>', unsafe_allow_html=True)
    grp = df.groupby(["source","sentiment"]).size().reset_index(name="count")
    fig3 = px.bar(grp, x="source", y="count", color="sentiment",
                  color_discrete_map={"Positive":NEON["positive"],"Negative":NEON["negative"]},
                  barmode="group", text="count")
    fig3.update_traces(textposition="outside", marker_line_width=0)
    fig3.update_layout(**PLOTLY_LAYOUT, title="Posts per Source", height=320,
                       yaxis_title="Posts", xaxis_title="")
    st.plotly_chart(fig3, use_container_width=True)

# ─── Row 3: Timeline ──────────────────────────────────────────────────────────
if "created" in df.columns:
    df["dt"] = pd.to_datetime(df["created"], errors="coerce")
    tdf = df.dropna(subset=["dt"]).copy()
    if not tdf.empty:
        st.markdown('<div class="sec-hdr"><div class="sec-hdr-bar"></div>Sentiment Timeline</div>', unsafe_allow_html=True)
        tdf["hour"] = tdf["dt"].dt.floor("h")
        tgrp = tdf.groupby(["hour","sentiment"]).size().reset_index(name="count")
        fig4 = px.line(tgrp, x="hour", y="count", color="sentiment", markers=True,
                       color_discrete_map={"Positive":NEON["positive"],"Negative":NEON["negative"]})
        fig4.update_layout(**PLOTLY_LAYOUT, title="Sentiment Over Time", height=300,
                           yaxis_title="Posts", xaxis_title="")
        st.plotly_chart(fig4, use_container_width=True)

# ─── Table ─────────────────────────────────────────────────────────────────────
st.markdown('<div class="sec-hdr"><div class="sec-hdr-bar"></div>All Posts</div>', unsafe_allow_html=True)
cols_want = [c for c in ["source","original_text","sentiment","created"] if c in df.columns]
disp = df[cols_want].copy()
disp.columns = [c.replace("_"," ").title() for c in disp.columns]

def _hl(v):
    return ("background:#052e16;color:#10FDAA" if v == "Positive"
            else "background:#450a0a;color:#FF4757" if v == "Negative" else "")
try:
    st.dataframe(disp.style.applymap(_hl, subset=["Sentiment"] if "Sentiment" in disp.columns else []),
                 use_container_width=True, height=440)
except Exception:
    st.dataframe(disp, use_container_width=True, height=440)

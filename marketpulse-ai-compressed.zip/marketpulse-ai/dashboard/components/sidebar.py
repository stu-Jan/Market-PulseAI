import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

import streamlit as st
from dashboard.utils.styles import GLOBAL_CSS


def inject_css():
    st.markdown(GLOBAL_CSS, unsafe_allow_html=True)


@st.cache_data(ttl=300, show_spinner=False)
def _run_cached_pipeline(topic: str, post_limit: int) -> dict:
    """Cache pipeline results for 5 minutes — avoids redundant API calls."""
    from agents.workflow import run_pipeline
    return run_pipeline(topic, post_limit=post_limit)


def _run_pipeline(topic: str, post_limit: int) -> dict:
    with st.status(f"Analysing **{topic}**…", expanded=True) as status:
        status.write("🌐 Fetching from Reddit & Google News…")
        results = _run_cached_pipeline(topic, post_limit)
        if results.get("error"):
            status.update(label=f"⚠️ Error — {results['error']}", state="error")
        else:
            pos = results["positive_pct"]
            neg = results["negative_pct"]
            status.write(f"🧠 Sentiment: {pos}% positive · {neg}% negative")
            status.write(f"🔑 Keywords extracted: {len(results.get('keywords', []))}")
            status.write(f"🚨 Alerts: {len(results.get('alerts', []))}")
            status.update(
                label=f"✅ Complete — {results['total_posts']} posts · {pos}% positive",
                state="complete", expanded=False,
            )
    return results


def render_sidebar() -> dict | None:
    with st.sidebar:
        st.markdown('<div class="sb-logo">📡 MarketPulse</div>', unsafe_allow_html=True)
        st.markdown('<div class="sb-tagline">Real-Time Sentiment Intelligence</div>', unsafe_allow_html=True)
        st.divider()

        st.markdown('<div class="sb-section">Topic</div>', unsafe_allow_html=True)
        topic = st.text_input(
            "topic", label_visibility="collapsed",
            value=st.session_state.get("last_topic", "Artificial Intelligence"),
            placeholder="🔍  e.g. ChatGPT, Tesla, Climate Change…",
        )

        st.markdown('<div class="sb-section">Posts to Collect</div>', unsafe_allow_html=True)
        post_limit = st.slider(
            "posts", 10, 1000, 100, step=10, label_visibility="collapsed",
            help="Reddit paginates 100/page. Google News caps at ~100. Total is combined.",
        )

        st.markdown('<div class="sb-section">Live Mode</div>', unsafe_allow_html=True)
        lc, ic = st.columns([1, 2])
        with lc:
            live = st.toggle("Auto", value=st.session_state.get("live_mode", False))
            st.session_state["live_mode"] = live
        with ic:
            mins = st.selectbox("Every", [5, 10, 15, 30], index=1, label_visibility="collapsed")

        if live:
            st.markdown('<span class="live-pill"><span class="live-dot"></span>LIVE</span>', unsafe_allow_html=True)
            try:
                from streamlit_autorefresh import st_autorefresh
                st_autorefresh(interval=mins * 60 * 1000, key="lr")
                if st.session_state.get("last_topic") == topic and st.session_state.get("analyzed"):
                    r = _run_pipeline(topic, post_limit)
                    st.session_state.update({"results": r, "last_topic": topic})
            except ImportError:
                st.caption("pip install streamlit-autorefresh")

        if st.button("▶  Analyze Now", use_container_width=True, type="primary"):
            st.session_state["last_topic"] = topic
            r = _run_pipeline(topic, post_limit)
            st.session_state.update({"results": r, "analyzed": True})

        r = st.session_state.get("results")
        if r:
            st.divider()
            st.markdown('<div class="sb-section">Last Run</div>', unsafe_allow_html=True)
            pc = "#10FDAA" if r["positive_pct"] >= 50 else "#FF4757"
            st.markdown(f"""<div style="background:rgba(10,16,32,0.6);border:1px solid rgba(51,65,85,0.4);
                border-radius:12px;padding:.75rem 1rem;font-size:.8rem">
                <div style="font-weight:700;color:#F1F5F9;margin-bottom:.3rem">📌 {r['topic']}</div>
                <div style="color:#64748B;margin-bottom:.35rem">🕐 {r['timestamp']}</div>
                <div style="display:flex;gap:.6rem">
                    <span style="color:#38BDF8">📄 {r['total_posts']} posts</span>
                    <span style="color:{pc}">● {r['positive_pct']}% pos</span>
                </div>
                <div style="color:#475569;margin-top:.3rem;font-size:.72rem">
                    {', '.join(r['sources_used']) or 'no sources'}
                </div>
            </div>""", unsafe_allow_html=True)
            h = sum(1 for a in r.get("alerts", []) if a["severity"] == "High")
            if h:
                st.markdown(f"<div style='margin-top:.4rem;padding:.45rem .8rem;background:rgba(127,29,29,0.3);"
                            f"border:1px solid rgba(220,38,38,0.35);border-radius:9px;font-size:.76rem;"
                            f"color:#FCA5A5'>⚠️ {h} critical alert{'s' if h>1 else ''}</div>",
                            unsafe_allow_html=True)

        st.divider()
        st.markdown("<div style='font-size:.67rem;color:#334155;text-align:center'>"
                    "MarketPulse AI v2.0 · No API keys required<br>Reddit · Google News · Trends · Gemini</div>",
                    unsafe_allow_html=True)

    return st.session_state.get("results")


def kpi_card(icon: str, label: str, value: str, color: str, delta: str = "", delay: float = 0) -> str:
    d = f"<div class='kpi-delta'>{delta}</div>" if delta else ""
    return (f'<div class="kpi-card c-{color}" style="animation-delay:{delay}s">'
            f'<div class="kpi-icon">{icon}</div>'
            f'<div class="kpi-lbl">{label}</div>'
            f'<div class="kpi-val c-{color}">{value}</div>{d}</div>')

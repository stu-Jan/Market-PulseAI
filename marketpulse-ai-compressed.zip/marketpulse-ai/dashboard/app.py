import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import streamlit as st

st.set_page_config(
    page_title="MarketPulse AI — Real-Time Public Sentiment Intelligence",
    page_icon="📡",
    layout="wide",
    initial_sidebar_state="expanded",
)

from dashboard.components.sidebar import inject_css, render_sidebar, kpi_card
inject_css()

st.markdown("""
<meta name="description" content="MarketPulse AI — Analyse public sentiment on any topic using Reddit, Google News, Google Trends and Gemini AI. Free, no API keys required for Reddit and News.">
<meta property="og:title" content="MarketPulse AI — Real-Time Sentiment Intelligence">
<meta property="og:description" content="Real-time ML sentiment analysis powered by Reddit, Google News, Google Trends and Gemini AI.">
<meta property="og:type" content="website">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="MarketPulse AI">
<meta name="robots" content="index, follow">
""", unsafe_allow_html=True)

# ─── HOME PAGE ─────────────────────────────────────────────────────────────────
results = render_sidebar()

if not results:
    st.markdown("""
    <div class="landing-wrap">
        <div class="landing-icon">📡</div>
        <div class="landing-title">MarketPulse AI</div>
        <div class="landing-sub">
            Real-time sentiment intelligence · No API keys needed for Reddit & News<br>
            ML sentiment · Google Trends · Gemini AI insights · CSV/Excel export
        </div>
    </div>""", unsafe_allow_html=True)

    st.markdown("<div style='text-align:center;margin-top:1rem'>", unsafe_allow_html=True)
    cols = st.columns(5)
    for col, ex in zip(cols, ["Artificial Intelligence", "Electric Vehicles", "Climate Change", "ChatGPT", "Tesla"]):
        col.markdown(f'<div class="topic-pill">💡 {ex}</div>', unsafe_allow_html=True)
    st.markdown("</div>", unsafe_allow_html=True)
    st.stop()

# ─── Hero ──────────────────────────────────────────────────────────────────────
live_badge = ('<div class="mp-hero-badge">'
              '<span class="live-dot" style="display:inline-block;width:6px;height:6px;'
              'background:#10FDAA;border-radius:50%;margin-right:4px;animation:pulse 1.2s infinite"></span>'
              'LIVE</div>') if st.session_state.get("live_mode") else ""

sr = results["sentiment_results"]
pos_n = sum(1 for r in sr if r["sentiment"] == "Positive")
neg_n = len(sr) - pos_n

st.markdown(f"""
<div class="mp-hero">
  {live_badge}
  <h1 class="mp-hero-title">📡 MarketPulse AI</h1>
  <div class="mp-hero-sub">Real-Time Sentiment & Trend Intelligence · Updated {results['timestamp']}</div>
  <div class="mp-hero-stats">
    <div><div class="mp-hero-stat-val" style="color:#38BDF8">{results['total_posts']}</div>
         <div class="mp-hero-stat-lbl">Posts Analysed</div></div>
    <div><div class="mp-hero-stat-val" style="color:#10FDAA">{results['positive_pct']}%</div>
         <div class="mp-hero-stat-lbl">Positive</div></div>
    <div><div class="mp-hero-stat-val" style="color:#FF4757">{results['negative_pct']}%</div>
         <div class="mp-hero-stat-lbl">Negative</div></div>
    <div><div class="mp-hero-stat-val" style="color:#A78BFA">{len(results['sources_used'])}</div>
         <div class="mp-hero-stat-lbl">Sources Active</div></div>
    <div><div class="mp-hero-stat-val" style="color:#FCD34D">{len(results['keywords'])}</div>
         <div class="mp-hero-stat-lbl">Keywords</div></div>
  </div>
</div>""", unsafe_allow_html=True)

# ─── KPI Grid ──────────────────────────────────────────────────────────────────
high_n  = sum(1 for a in results["alerts"] if a["severity"] == "High")
kw_top  = results["keywords"][0][0] if results["keywords"] else "—"
recs_n  = len(results["recommendations"])
alrt_n  = len(results["alerts"])

st.markdown(
    '<div class="kpi-grid">'
    + kpi_card("📄", "Total Posts",  str(results["total_posts"]),     "blue",   "Reddit + Google News",      .04)
    + kpi_card("🟢", "Positive",     f"{results['positive_pct']}%",   "green",  f"{pos_n} posts",            .08)
    + kpi_card("🔴", "Negative",     f"{results['negative_pct']}%",   "red",    f"{neg_n} posts",            .12)
    + kpi_card("🔑", "Top Keyword",  kw_top,                          "purple", f"{len(results['keywords'])} extracted", .16)
    + kpi_card("🎯", "Actions",      str(recs_n),                     "cyan",   "AI recommendations",        .20)
    + kpi_card("🚨", "Alerts",       str(alrt_n),                     "red" if high_n else "amber",
                                                                                f"{high_n} critical" if high_n else "All clear", .24)
    + '</div>',
    unsafe_allow_html=True,
)

# ─── Status + Summary ──────────────────────────────────────────────────────────
col1, col2 = st.columns([1, 2])

with col1:
    st.markdown('<div class="sec-hdr"><div class="sec-hdr-bar"></div>System Status</div>', unsafe_allow_html=True)

    tr = results.get("trends", {})
    trends_ok = (tr.get("error") is None
                 and tr.get("interest_over_time") is not None
                 and hasattr(tr["interest_over_time"], "empty")
                 and not tr["interest_over_time"].empty)
    ins = results.get("insights", "")
    gemini_ok = bool(ins and not ins.startswith("⚠️")
                     and "not set" not in ins and "failed" not in ins.lower()
                     and "not installed" not in ins)

    checks = [
        ("🌐", "Reddit",        "Reddit" in results["sources_used"]),
        ("📰", "Google News",   "Google News" in results["sources_used"]),
        ("📊", "Google Trends", trends_ok),
        ("🤖", "Gemini AI",     gemini_ok),
        ("🧠", "ML Sentiment",  results["total_posts"] > 0),
    ]
    for ico, name, ok in checks:
        dc = "on" if ok else "off"
        lbl = "Active" if ok else ("Add key to .env" if name == "Gemini AI" else "Unavailable")
        st.markdown(f"""<div class="status-item">
            <div class="s-dot {dc}"></div>
            <span class="s-name">{ico} {name}</span>
            <span class="s-label {dc}">{lbl}</span>
        </div>""", unsafe_allow_html=True)

with col2:
    st.markdown('<div class="sec-hdr"><div class="sec-hdr-bar"></div>Pipeline Summary</div>', unsafe_allow_html=True)
    st.markdown(f"""<div class="glass">
        <pre style="white-space:pre-wrap;font-family:'Inter',monospace;color:#CBD5E1;
                    font-size:.84rem;margin:0;line-height:1.75">{results['summary']}</pre>
    </div>""", unsafe_allow_html=True)

# ─── Alerts preview ────────────────────────────────────────────────────────────
st.markdown('<div class="sec-hdr"><div class="sec-hdr-bar"></div>Alerts</div>', unsafe_allow_html=True)
sev_ico = {"High": "🔴", "Medium": "🟡", "Low": "🟢"}
for i, a in enumerate(results["alerts"][:5]):
    sev = a["severity"].lower()
    st.markdown(f"""<div class="a-card {sev}" style="animation-delay:{i*0.07}s">
        <span class="a-sev-badge {sev}">{sev_ico.get(a['severity'],'•')} {a['severity']}</span>
        <div>
            <div class="a-text">{a['message']}</div>
            <div class="a-type">{a.get('type','')}</div>
        </div>
    </div>""", unsafe_allow_html=True)

if results.get("error"):
    st.error(f"Pipeline error: {results['error']}")

# ─── Export ────────────────────────────────────────────────────────────────────
st.divider()
st.markdown('<div class="sec-hdr"><div class="sec-hdr-bar"></div>Export</div>', unsafe_allow_html=True)
from dashboard.utils.export import results_to_dataframe, to_csv_bytes, to_excel_bytes
df = results_to_dataframe(results)
slug = results["topic"].replace(" ", "_")
ec1, ec2, _ = st.columns([1, 1, 5])
ec1.download_button("⬇ Download CSV",   to_csv_bytes(df),   f"marketpulse_{slug}.csv",  "text/csv",            use_container_width=True)
ec2.download_button("⬇ Download Excel", to_excel_bytes(df), f"marketpulse_{slug}.xlsx", use_container_width=True)

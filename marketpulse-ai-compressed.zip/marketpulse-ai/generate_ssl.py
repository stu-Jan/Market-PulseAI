"""Generate self-signed SSL cert for localhost HTTPS — run once."""
import subprocess, os, sys

os.makedirs("ssl", exist_ok=True)

cmd = [
    "openssl", "req", "-x509", "-newkey", "rsa:4096",
    "-keyout", "ssl/key.pem",
    "-out",    "ssl/cert.pem",
    "-days",   "365",
    "-nodes",
    "-subj",   "/C=US/ST=Dev/L=Local/O=MarketPulseAI/CN=localhost",
    "-addext", "subjectAltName=IP:127.0.0.1,DNS:localhost",
]

try:
    subprocess.run(cmd, check=True)
    print("\n✅ SSL certificate generated in ssl/")
    print("\nTo run Streamlit with HTTPS:")
    print("  streamlit run dashboard/app.py --server.port 8502 --server.sslCertFile ssl/cert.pem --server.sslKeyFile ssl/key.pem")
    print("\nTo use Nginx (adds security headers):")
    print("  nginx -c nginx.conf")
    print("\nTo use Caddy (easiest, auto-HTTPS):")
    print("  caddy run")
except FileNotFoundError:
    print("openssl not found.")
    print("Install: https://slproweb.com/products/Win32OpenSSL.html")
    print("\nAlternative — use Caddy for one-click HTTPS + security headers:")
    print("  Download: https://caddyserver.com/download")
    print("  Run:      caddy run")

import feedparser
import re
from urllib.parse import quote_plus


def get_news_posts(topic: str, limit: int = 30) -> list:
    try:
        query = quote_plus(topic)
        url = f"https://news.google.com/rss/search?q={query}&hl=en-US&gl=US&ceid=US:en"
        feed = feedparser.parse(url)

        posts = []
        for entry in feed.entries[:limit]:
            raw_summary = getattr(entry, "summary", "")
            summary = re.sub(r"<[^>]+>", "", raw_summary).strip()
            text = entry.get("title", "") + ". " + summary

            source_name = "Google News"
            if hasattr(entry, "source") and isinstance(entry.source, dict):
                source_name = entry.source.get("title", "Google News")

            posts.append({
                "source": "Google News",
                "text": text,
                "url": entry.get("link", ""),
                "score": 0,
                "created": entry.get("published", ""),
                "subreddit": source_name,
            })

        return posts

    except Exception as e:
        print(f"Google News fetch error: {e}")
        return []

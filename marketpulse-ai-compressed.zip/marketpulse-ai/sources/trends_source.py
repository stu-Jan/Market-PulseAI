import pandas as pd
import time

try:
    from pytrends.request import TrendReq
    _PYTRENDS_AVAILABLE = True
except ImportError:
    _PYTRENDS_AVAILABLE = False


def get_trends_data(topic: str) -> dict:
    empty = {
        "interest_over_time": pd.DataFrame(),
        "top_queries": [],
        "rising_queries": [],
        "emerging_topics": [],
        "topic": topic,
        "error": None,
    }

    if not _PYTRENDS_AVAILABLE:
        empty["error"] = "pytrends not installed"
        return empty

    for attempt in range(3):
        try:
            pytrends = TrendReq(
                hl="en-US", tz=330,
                timeout=(15, 30),
                retries=2,
                backoff_factor=1.0,
                requests_args={"verify": True},
            )
            time.sleep(1 + attempt)

            pytrends.build_payload([topic], cat=0, timeframe="now 7-d", geo="", gprop="")

            interest_df = pytrends.interest_over_time()
            if not interest_df.empty:
                interest_df = interest_df.drop(columns=["isPartial"], errors="ignore")

            time.sleep(0.8)
            related = pytrends.related_queries()
            top_queries, rising_queries = [], []
            if topic in related:
                tq = related[topic].get("top")
                rq = related[topic].get("rising")
                if tq is not None and not tq.empty:
                    top_queries = tq.head(10).to_dict("records")
                if rq is not None and not rq.empty:
                    rising_queries = rq.head(10).to_dict("records")

            time.sleep(0.8)
            related_topics = pytrends.related_topics()
            emerging = []
            if topic in related_topics:
                rt = related_topics[topic].get("rising")
                if rt is not None and not rt.empty and "topic_title" in rt.columns:
                    emerging = rt.head(6)["topic_title"].tolist()

            return {
                "interest_over_time": interest_df,
                "top_queries": top_queries,
                "rising_queries": rising_queries,
                "emerging_topics": emerging,
                "topic": topic,
                "error": None,
            }

        except Exception as e:
            err = str(e)
            if attempt < 2:
                time.sleep(3 + attempt * 2)
                continue
            print(f"Google Trends error after {attempt+1} attempts: {err}")
            empty["error"] = err
            return empty

    return empty

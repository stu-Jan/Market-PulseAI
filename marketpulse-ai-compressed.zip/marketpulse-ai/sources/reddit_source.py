import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import requests
import time
from datetime import datetime, timezone
from urllib.parse import quote_plus


_HEADERS = {
    "User-Agent": "Mozilla/5.0 MarketPulseAI/2.0 (research tool)",
    "Accept": "application/json",
}


def get_reddit_posts(topic: str, limit: int = 100) -> list:
    """Fetch Reddit posts using the public JSON API — no API key required."""
    posts = []
    after = None
    collected = 0
    max_pages = min(10, (limit // 100) + 1)

    for _ in range(max_pages):
        if collected >= limit:
            break

        batch = min(100, limit - collected)
        url = (
            f"https://www.reddit.com/search.json"
            f"?q={quote_plus(topic)}&sort=new&limit={batch}&type=link,self&t=month"
        )
        if after:
            url += f"&after={after}"

        try:
            resp = requests.get(url, headers=_HEADERS, timeout=12)
            if resp.status_code == 429:
                time.sleep(3)
                continue
            if resp.status_code != 200:
                break

            data = resp.json()
            children = data.get("data", {}).get("children", [])
            if not children:
                break

            for child in children:
                d = child.get("data", {})
                text = d.get("title", "").strip()
                selftext = d.get("selftext", "").strip()
                if selftext and selftext not in ("[deleted]", "[removed]") and len(selftext) > 10:
                    text += " " + selftext[:400]

                created_ts = d.get("created_utc", 0)
                created_str = datetime.fromtimestamp(created_ts, tz=timezone.utc).strftime("%Y-%m-%d %H:%M")

                posts.append({
                    "source": "Reddit",
                    "text": text,
                    "url": f"https://reddit.com{d.get('permalink', '')}",
                    "score": d.get("score", 0),
                    "created": created_str,
                    "subreddit": d.get("subreddit", ""),
                })
                collected += 1

            after = data.get("data", {}).get("after")
            if not after:
                break

            time.sleep(0.8)

        except Exception as e:
            print(f"Reddit public API error: {e}")
            break

    return posts[:limit]

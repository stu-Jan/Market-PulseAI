from sources.reddit_source import get_reddit_posts
from sources.news_source import get_news_posts


def collect_all_posts(topic: str, reddit_limit: int = 50, news_limit: int = 30) -> list:
    reddit_posts = get_reddit_posts(topic, limit=reddit_limit)
    news_posts = get_news_posts(topic, limit=news_limit)
    return reddit_posts + news_posts
